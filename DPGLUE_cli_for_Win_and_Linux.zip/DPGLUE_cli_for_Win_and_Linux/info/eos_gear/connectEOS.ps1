# new v1.1.2 shim to EOS as part of DPGLUE
# do not execute manually!
# MjK w/ initial guidance KP
# Purpose of this program is for DPG to use WIN PS to SF lib to connect to Element 11

$var_str_TARGET=$args[0]
$var_str_USERNAME=$args[1]
$var_str_PWD=$args[2]
$var_str_MYVOL=$args[3]
$var_str_MYSNAP=$args[4]

If ($var_str_TARGET  -eq '-dpgH') #say hello
{
	
	write-host "hello"
	exit 0

}
Else
{
	Try 
	{
		write-host "Attempting to connect to SF Cluster."
		Connect-SFCluster -Target $var_str_TARGET -UserName $var_str_USERNAME -Password $var_str_PWD
		write-host "SF Cluster connect occurred. OK-dpg."
		exit 0
	}
	Catch
	{
		write-host "SF Cluster connect has not occurred. ERROR-dpg."
		exit 1

	}
}
exit 0

