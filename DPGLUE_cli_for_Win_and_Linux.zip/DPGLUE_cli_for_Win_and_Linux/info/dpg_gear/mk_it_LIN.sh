#!/bin/sh
# BASH should be used not csh nor ksh etc
# This is a GNU/Linux shell script
# Role is trivial and elective
# new v1.1.2 aka 112 shim for ease of use of DPG
# MjK 
# Purpose of this program is for DPG Admin to convert this plugin to LIN based
# Assumes the Plugin is in WIN mode presently before execution of this program
# There is no error handling whatsoever
# Must be executed from within the directory which this program exists
# for instance and assuming executable permissions on behalf of the User has been present
#	./mk_it_LIN.sh 
# Since this only echoes to cli you may wish to redirect it to your own program to run after checking contents


echo Start by unzip contents of the Windows version of the Plugin


[ -f  ../../DPGLU.EXE ] && echo mv ../../DPGLU.EXE ../../W_x_DPGLU_EXE_x_na
[ -f  ../../dpgl.exe ] && echo mv ../../dpgl.exe ../../W_x_dpgl_exe_x_na
[ -f  ../../Plugin_descriptor.xml ] && mv ../../Plugin_descriptor.xml ../../W_x_Plugin_descriptor_xml_x_na
[ -f  ../../DPGLUE.BAT ] && echo mv ../../dpgl.exe ../../W_x_DPGLUE.BAT_x_na

[ -f  ../../DPGLU.BIN ] || echo cp ../dpg_gear/DPGLU.BIN ../../DPGLU.BIN
[ -f  ../../DPGLUE.sh ] || echo cp ../sc_plugin_gear/DPGLUE.sh ../../DPGLUE.sh
[ -f  ../../dpgl.bin ]  || echo cp ../dpg_gear/DPGLU.BIN ../../dpgl.bin
[ -f  ./../Plugin_descriptor.xml ] || echo cp ../sc_plugin_gear/Plugin_descriptor.xml_LIN ../../Plugin_descriptor.xml

echo And ensure that all files are executable

echo Then zip up again to sane file Plugin name as was Windows version


