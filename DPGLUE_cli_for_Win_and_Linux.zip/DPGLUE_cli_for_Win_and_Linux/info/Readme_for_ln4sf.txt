#########################################################################
      >> This document may have unintentional errors. <<
#########################################################################
#########################################################################

            					Readme Information 
            								
            								for 

            	the DUBR Module's "ln4sf" Sub-module

            							when using

    SnapCenter Plugin for DP Glue v.1.1.2 aka 1.12 or 1.1P2

#########################################################################

The name "ln4sf" abbreviates the capability of a local node issuing
commands on behalf of (aka "for") SolidFire via its API.

#########################################################################

This is the Readme File for "DUBR" module and specifically
its sub-module "ln4sf", which allows for SnapCenter perform
basic operations from a WIN or LIN local host to SolidFire, namely its
Element API.

The sub-module performs snaps, tests, filesystem syncs and 
like ops on the Element OS found with SolidFire.

In combination with the "ln2sf" sub-module, this represents
a powerful addition to the SnapCenter plug-ins.

Using examples is best way to explain the sub-module below.

#################################################################################

Goal of this Sub-module is to

  Provide the capability to snapshot a SolidFire volume, especially when using  
  SolidFire as a target. This is performed with the particular “ln4sf” 
  sub-module of the DUBR module. The parameter systax is “-ln4sf-rsnap-1 ….” etc. 
  Consult the associated Readme file under “info” subdirectory. 
  This uses the Restful API. 

  Further, using the “ln4sf” sub-module, you can combine DPGLUE with existing   
  SnapCenter application/database plug-ins that use SolidFire Volumes. Remember 
  the   Administration interface of SnapCenter allows another snap tool to be used 
  instead of the default snapshot tool that comes with SnapCenter. The default tool 
  assumes   ONTAP as the storage provider for the application; while “ln4sf” 
  assumes Element! To be used by non DP GLUE plug-ins, the “-ln4sf-psnapsync-1” 
  or “-ln4sf-rsnapsync-1” are used.

  Provide a means to flush filesystem buffers to disk, especially when using   
  SolidFire as a target and performing a snap. This is performed with the “ln4sf” 
  sub-module of the DUBR module. The parameter systax is “-ln4sf-fsync-1 ….” etc.
  Consult the associated Readme file under “info” subdirectory.*

  Also provide optional for Pshell snaps of SF volumes, especially when using
  SolidFire as a target. This is performed with the particular “ln4sf” 
  sub-module of the DUBR module. The parameter systax is “-ln4sf-psnap-1 ….” etc. 
  Consult the associated Readme file under “info” subdirectory. This uses the WIN 
  powershell tool kit.

  From CLI, the “-ln4sf-mk64e-1 ...” is used to base64 encode the login and pwd  
  used when “rsnap” is used. 

  From either plug-in or CLI modes, the “-ln4sf-hello-1” is used as a read-only
  check on the environment.


#################################################################################

There are known limitations. 


      * Please see limitations in the Readme_Before_Using.txt


#################################################################################

It is assumed you have already read the helpful information found
in the Readme_Before_Using.txt file.

#################################################################################

[ FYI ]
---------------------------------
  
  This document should be read entirely. 

  Case-sentive !

  Using in CLI mode, the end user uses DPGLU.EXE|BIN or dpgl.exe|bin.
  Obviously, .exe is for WIN, and .bin is for LIN. In CLI, you will
  use the 3 arguments eg --dubr --ln4sf "a,b,c,d,e,f,g" on the 
  command line. By now, you read in the Readme Before Using doc.

  Plug-in mode is exactly the same syntax, but as you read in the Readme 
  Before Using doc, you let SnapCenter call DPGLUE.bat|.sh. 
  Obviously, .bat for WIN oriented plug-in and .sh for LIN.  Instead of
  command-line arguments, the 3 arguments are same as above but they 
  are placed in 3 environment variables.

[ TERMS ]
---------------------------------

	SnapCenter 4.x is also referred to as SCenter.

  DPG, DP Glue are the same.

  1MB is 1048576 bytes. This is related to user defined buffering.

	DUBR is the same as its ln2on sub-module in this document.

  DEST is same as DESTINATION or TARGET.

  SRC is same as SOURCE.

  Local storage is same as DAS.

  SF refers to SolidFire

  HCI refers to SolidFire storage portion

  EOS refers to the OS used on SolidFire known as Element OS

  LIN is linux

  WIN is win64 from MS

  SC is SnapCenter

  "na" means not applicable and an parameter that is not used

  Plug-in and plugin are synonymous

#################################################################################

[ Conceptual Architecture ]
---------------------------------

> Use Case Example

* Let's say an IT group uses NetApp SnapCenter and NetApp ONTAP LUNs
* But there is a WIN or LIN server that has local storage only
* The host stores DB or application dumps / output directories and files 
  that need replicated / copied / protected on to a NetApp target
* SnapCenter does not offer agents for OS not using NetApp storage
* The cost cannot be justified to buy yet another backup solution for these few
* After all, the database has capabilities to backup itself
* So the DBA dumps data backups each night to a "dump file"
* SnapCenter Admin needs to protect that dump file
* What does one do?

> Inferior Approach

* The DB / App Admin could be given a Volume (LUN) on NetApp SF
* It can be mounted to the "WIN" or "LIN" host as a Filesystem
* And that Admin could simply adjust the dumps / output to go there
* However it would not be managed centrally, would take longer to complete
  over the network and has no centralized scheduling/monitoring

> Better Approach

* SnapCenter 4x could use the DP GLUE, particulary the DUBR module
* The important replication and versioning of directories/files 
  to NetApp target can be centrally managed
* And once it lands on NetApp it can be protected with NetApp ONTAP snapshot 
* Success, failure and details are recorded

> How 

* Using SCenter 4x, one would deploy the DP Glue plugin-mode
* The WIN or LIN host that is part of SCenter would run DP Glue
* DP Glue would replicate the special dirs/files to NetApp (eg ONTAP) target
* DP Glue manages runlevel codes and interfaces that SCenter expects
* Once complete SCenter will record the logs and results
* Because SnapCenter does not snapshot EOS, this submodule could be used
* And even with sync of filesystems on LIN or drives on WIN


[Syntax & Examples]
---------------------------------

> The examples here are CLI mode using
command line arguments.

> As mentioned above and explained below,
plug-in mode uses these same argument
just contained in environment variables.

> DPGLUE is case sensitive as a whole

> You cannot "flush sync" 
  a NAS mount/map 

> when installing MS Sync, you must run sync64 manually
  one time to accept the license

> -dubr and --dubr are equivalent as well as
  
> -ln4sf and --ln4sf are equivalent

> It is advised that the SF Admin create a specific user for SnapCenter 
  that has limited priviledges!

> Use of quotes and single quotes

  * Note, a rule of thumb is that when using Linux, the argument known as 
    the DATIVE should be enclosed in single quotes. While with WIN use
    double quotes

> When using command-line ("CLI") and not plugin, the following is used:

    DPGLU.EXE in WIN
    DPGLU.BIN in LIN

> The current working directory for CLI should be the same as where DPGLU.EXE
    or DPGLU.BIN is stored, namely the parent directory of DPGLUE

> In CLI you may copy DPGLU.EXE to dpgl.exe
    and DPGLU.BIN to dpgl.bin and use those instead
    AND we did so for our examples below

> But, the SC plugin mode uses DPGLUE.bat in WIN 
    and DPGLUE.sh in LIN
    and they cannot both occupy the parent directory of the
    zip files or it confuses SC

> Overall, one can access the ln4sf submodule in this way ...

    WIN uses
    [DPGLU.EXE | dpgl.exe] -dubr -ln4sf-[...]-1[--v] "a,b,c,d,e,f,g"

    LIN uses
    [DPGLU.EXE | dpgl.exe] -dubr -ln4sf-[...]-1[--v] 'a,b,c,d,e,f,g'

    as you can see, noted above, LIN uses '' and WIN ""
    for the 3rd argument

    as you can see there are merely 3 arguments, namely,
    the MODULE and the MODIFIER and the DATIVE

    the MODULE for ln4sf is always -dubr

    the MODIFIER would be like this
    -ln2sf-<psnap|rsnap|fsync|mk64e|hello|rsnapsync|psnapsync>-1 

    and the DATIVE is in the format 
    it has 7 parameters that need to be filled in,
    with comma or tilde may be used as the delimeter

> Functionality examples

  "-fsync-1" is
    sync filesystems
    by attempting to flush the buffers 
    of all filesystems in LIN 
    or a drive letter on WIN 
    you would use eg

    WIN
    dpgl.exe --dubr --ln4sf-fsync-1 "jobx1,E,na,na,na,na,na"
    (assuming MS sync64.exe is installed)
    
    LIN
    dpgl.bin --dubr --ln4sf-fsync-1 'jobx1,na,na,na,na,na,na'
    because LIN will flush all OS filesystems using sync OS command
    (alet!) again all filesystems


  "-rsnap-1" to
    snap shot a volume on SF
    using Restful API
    you would use eg

    WIN
    dpgl.exe --dubr --ln4sf-rsnap-1 "jobx1,sfcluster1,_b64e,xauthx,2,snapx1,12"
    this will create a snapshot without FS flushing
    of the active volume ID 2
    whose name would be dpg_jobx1_<specialtimestamp>_snapx1
    that is retained for 12 hours

    LIN
    dpgl.bin --dubr --ln4sf-rsnap-1 'jobx1,sfcluster1,_b64e,xauthx,2,snapx1,12'
    this will create a snapshot without FS flushing
    of the active volume ID 2
    whose name would be dpg_jobx1_<specialtimestamp>_snapx1
    that is retained for 12 hours

  "-rsnapsync-1" to
    same as the rsnap but a sync will be attempted before snap
    however, WIN flushes all Filesystems just like LIN

  "mk64e-1" is to
    generate a base64 encoded authentication string for Rest API
    to be used with the rsnap option
    ( assuming MS sync64.exe is installed on WIN host)
    you would use eg

    WIN
    dpgl.exe -dubr -ln4sf-mk64e-1 "jobx1,admin:somethingpwd,na,na,na,na,na"
    the output to the screen will be the string to use
    use this string with _b64e like above (we used xauthx as example) 

    LIN
    by now, you know that LIN is like WIN 
    except .bin
    and single quotes

  "-psnap-1" 
    snap shot a volume on SF
    using Restful API
    you would use eg

    WIN only
    dpgl.exe -dubr -ln4sf-psnap-1 "jobx1,sfcluster1,scadmin,xpwdx,VolWin1Lun,snapx1,24"
    this will create a snapshot without FS flushing
    of the active volume named VolWin1Lun
    whose name would be dpg_jobx1_<specialtimestamp>_snapx1
    that is retained for 24 hours
    using a hardcoded (alert!) login to SF of scadmin
    and a hardcoded (alert!) login to SF of xpwdx

  "-psnapsync-1" to
    same as the psnap but a sync will be attempted before snap
    however, WIN flushes all Filesystems just like LIN


> Using Plug-in mode, environmental variables are used 
   which are 1 per argument. They are explained in next section. 

    Remember SnapCenter calls in WIN
    DPGLUE.bat 

    And SnapCenter calls in LIN
    DPGLUE.sh


...
THE FOLLOWING ... is cut and pasted from like sections in ln2on
... 

[ Using with SCenter as Custom Plugin]
---------------------------------

> Basic Steps

* Follow all directives found in DPGLUE\Readme_Before_Using.txt
* Ensure SCenter 4x is running in the environment
* Know that DP Glue is for 64bit OS
* And it is case sensitive
* Assume NetApp ONTAP SAN/NAS is the target (CVO / OTS / OnPrem)
* Deploy DP Glue properly in plugin-mode into SCenter 
      - This means the SC Admin will prepare the DP GLUE Plugin
        using the Readme_Before_Using.txt
      - The final zip file prepared using these Readme instructions
        will be called "SnapCenter Plug-in for DP Glue.zip"
      - The SC Admin will uploade this zip file to SnapCenter
        by selecting a desired host in the SnapCenter GUI, and
        performing a Modify the Add Plugin.
      - Such a host is one that does not use NetApp technology 
        for its storage, but rather DAS / local disk.
      - Ensure SnapCenter has had at least (1) ONTAP system
        added to its management.
      - Using SnapCenter, you will create a LUN or NAS Share
        (a Volume with protocol access of iSCSI, CIFS or NFS)
        on this ONTAP system that the desired host can access
        and write its backup replicas to.
      - often NAS Shares work best, especially since CIFS
        UNCs are support
      - You will then create a Resource of type DP Glue and
        with the property of DAS Host Filesystems
      - When you then click on this newly created Resource twice
        a Resource Group wizard will appear.
      - When you create the resource group job, the ONTAP Volume
        created above will be pre-requisite, and you will enter
        it in the wizard. For instance, if you are using H:\
        as a mountpoint to the ONTAP Volume over the CIFS protocol
        then you would enter H:\ in the dialog requiring such a
        filesystem area
      - You will not be able to filesystem quiesce the 
        source dirs/files on the desired host because it is not on NetApp
      - As you continue to use the Resource Group wizard, the
        custom Application key value pairs must
        be set using the keys DPG_ARG1_QUI, DPG_ARG2_QUI and DPG_ARG3_QUI
        and also using the keys DPG_ARG1_UNQ, DPG_ARG2_UNQ and DPG_ARG3_UNQ
      - It is wise to set the UNQ values to do nothing using the 
        underscore such as "d_f". SnapCenter will run an unquiesce, so
        you must set these UNQ values. But all the work was done during 
        quiesce.
      - Under this item in the wizard is another section that asks if you
        wish to make a filesystem consistent snapshot. If you are using a
        NetApp LUN as your ONTAP Volume target, then you can say Yes.
        Otherwise always say no. (It defaults to yes !)
      - Set up the desired schedules and other parameters to complete
        the SC workflow

> What SC does with the Resource Group JOB you set up for the Host?

      - When the Resource Group's backup is triggered
      - the first command sent to DP GLUE will be "-quiesce"
      - DP GLUE will follow the instructions given it
        by using the values provided by the custom application key value pairs,
        namely, DPG_ARG1_QUI, DPG_ARG2_QUI and DPG_ARG3_QUI.
      - These will replicate dirs/files from the desired host to
        the ONTAP Volume you created for it
      - SnapCenter will record whether DP Glue succeeds or not
      - Assuming success it will snapshot ONTAP Volume, protecting the 
        replica of the desired host's dirs/files
      - SC will then send the 2nd command to DP GLUE, namely "-unquiesce"
      - DP GLUE will follow the instructions given it
        by using the values provided by the custom key value pairs,
        namely, DPG_ARG1_UNQ, DPG_ARG2_UNQ and DPG_ARG3_UNQ.



> What SC commands to DP Glue are supportable?

  	  -describe	     supported, not used by SC

      	- or -
      
      -discover      not supported
      
        - or -
      
      -quiesce       supported, currently used by SC;
                     requires 3 Key/Value pairs with _QUI suffix.
      
        - or -
      
      -unquiesce     supported, currently used by SC;
                     requires 3 Key/Value pairs with _UNQ suffix.
      
        - or -
      
      -restore_pre   supported, not used by SC
      
        - or -
      
      -restore_pre   supported, not used by SC
      
        - or -
      
      -clone_pre	   supported, not used by SC
      
      	- or -
      
      -clone_post    supported, not used by SC
      
        - or -
      
      -scdump        supported, not used by SC
      
        - or -
      
      -backup        supported, not used by SC
      
        - or -
      
      -run           supported on command-line only for testing
                     requires the 3 Key/Value pairs with _RUN suffix
                     in the runtime environment.


> What are the specifics around the customized key value pairs?

    * Again, as part of the workflow for setting up a Resource
      Group Job, (6) key value pairs must be set up in the
      section of the SC wizard known as Customer Key Value Pairs
      when you setup the Resource Group Job
    * Again, they are: 

        - DPG_ARG1_QUI, DPG_ARG2_QUI and DPG_ARG3_QUI, which
          are used when SC sends DP GLUE the "-quiesce" command

          and

        - and DPG_ARG1_UNQ, DPG_ARG2_UNQ and DPG_ARG3_UNQ, which
          are used when SC sends DP GLUE the "-unquiesce" command

    * As mentioned above, the -quiesce and -unquiesce are the
      only commands SC will send DP GLUE presently. This is 
      why *_QUI and *_UNQ suffixes on the keys are relevant.

    * When setting the values for these 6 keys, following this standard:

        DPG_ARG1_<QUI|UNQ> set to a value known as a module, no quotes. More below.
         
         	- and -
         
         DPG_ARG2_<QUI|UNQ> set to a value known as a modifier, in double quotes. More below.
        
        	- and -
         
        DPG_ARG3_<QUI|UNQ> set to a value known as a dative, in double quotes. More below.

    * Whereby the "_<QUI|UNQ>" is replaced by one of these suffixes.

       Currently these suffixes are supported in plugin-mode:

       _QUI as the suffix for when the SC command is -quiesce
       _UNQ as the suffix for when the SC command is -unquiesce


* The value for the DPG_ARG1_<QUI|UNQ> key follows this guidance:

    - this is called the module key/value pair
    - sometimes called "DPG Arg 1"
    - set this always to "dubr" w/o any quotes at all
    - for instance DPG_SC_ARG1_MODULE_QUI=-dubr
    - Reference the information above around MODULE syntax

* The value for the DPG_SC_ARG2_MODIFIER_<QUI|UNQ> key follows this guidance:

    - this is called the modifier key/value pair
    - sometimes called "DPG Arg 2"
    - place the value inside double quotes
    - Reference the information above around MODIFIER syntax
    - for instance "--ln4sf-<whatever>-1" etc

* The value for the DPG_SC_ARG3_DATIVE_<QUI|UNQ> key follows this guidance:

    - this is called the dative key/value pair
    - sometimes called "DPG Arg 3"
    - place the value inside double quotes
    - note the use of ~ ; however commas , can be used a delims too
    - Reference the information above around MODIFIER syntax
    - for instance "job,etc,etc,etc,etc,etc,etc" WIN
   

[ VERBOSITY ]
---------------------------------

* adding "--v" to the end of MODIFIER argument makes
  verbosity occur so you can trouble shoot
EXAMPLE:  "-ln4sf-<whatever>-1--v"

[ CALLOUTS ]
---------------------------------

* There is no promise that this document does not have mistakes
* There could be errors in this doc or in the software that could loss data
* TEST and use with care


#####################################CONCLUSION##################################

[ NOTE WELL ]
---------------------------------
SnapCreator, SnapCenter & SnapProtect are products from NetApp.
NetApp Data Fabric is from NetApp as well.
PostgreSQL is 3rd party example see www.postgres.org

#####################################END#########################################
This document was revised on 23-APR-2020. Content may be dated.
#################################################################################

