#########################################################################
				>> This document is not error-free. <<
#########################################################################
#########################################################################

					Secondary Readme Information 
								
								for 

				The SCGL Module's "cx2sc" Sub-module

							when using

    		with SnapCenter Plugin for DP Glue v.1.x untested

#########################################################################

THIS WAS DEPRECATED in the PREVIOUS VERSION OF DP Glue.
IT IS NO LONGER TESTED. IT IS NO LONGER MAINTAINED.
	
#########################################################################




.
	The name "cx2sc" abbreviates for Common Exchanger 
	to SnapCreator
.

#########################################################################

This is the Readme File for "SCGL" program and specifically
its sub-module "cx2sc", which allows for common xchanger to 
call SnapCreator 4.x.

This common xchanger aims to be used by SnapCenter. 

It may be used by backup software from traditional products 
using Pre and Post capabilities in these products

SnapCenter execution of this sub-module will result in the error codes expected
by the product's API. 
#################################################################################

Although this sub-module's function will become less important as end-users
transition to SnapCenter, it is hoped that for now SnapCenter can utilize it
to run SnapCreator 4.x jobs.

This sub-module simply executes SnapCreator from command-line on the WIN host
where SnapCreator Server is installed using the profile/config setup 
beforehand in SnapCreator GUI or manually.

The particular db/app that requires quiesce/unquiesce by SnapCreator may
be located on WIN or LIN using the AGENT capabilites of SnapCreator.

################################################################################# 

To understand this document, first read :

	DPGLUE\SC_GLUE\README_BEFORE_USING.txt

#################################################################################

[ TERMS ]
---------------------------------

	SnapCenter 3.x is also referred to as SCenter too.

	SnapCreator 4.x is also referred to as SCreator as well.

	SnapCreator Server is referred as ScServe[r] as well.

	SnapCreator Agent is referred as ScAgent as well.

	DPG, DP Glue are the same.

	SCGL is the same as SCGL's cx2sc sub-module in this document.

#################################################################################

[ Conceptual Architecture ]
---------------------------------

> Situation

* Imagine a Linux host that has a LUN on NetApp cDOT
* That Linux host stores a PostgreSQL Database there
* presently SnapCenter does not support PostgreSQL
* however, SCenter can backup OS LUNs stored on ONTAP 
* yet, SnapCreator 4.x can quiesce/unquiesce PostgreSQL
* What do you do?

> Approach

* Using SCenter 3x, one would deploy the DP Glue plugin-mode
* On a separate WIN host, you would install SCreator 4x ScServer
* The PostgreSQL plugin for SCreator would be further installed
* On the Linux server running PostgresSQL you would deploy ScAgent
* with "cx2sc" handling SCreator, proper extension of SCenter occurs
* DP Glue manages runlevel codes and interfaces that SCenter expects

> Caution

* The challenge to consider is HOW LONG the database will be in quiesced mode
* TEST TEST TEST TEST


[ INTEGRATION of DP Glue ]
 ---------------------------------

> Basic Steps

* Follow all directives found in DPGLUE\Readme_Before_Using.txt
* Ensure SCenter 3x is running in the environment
* Deploy DP Glue properly in plugin-mode into SCenter using WIN method
* You will have your legacy SCreator running on WIN 64bit as ScServer
* Lastly, install ScAgent on the host with db/app you want quiesce/unquiesce

> SCreator Requirements

* You will need to create a profile/config using SnapCreator GUI or the --setup (CLI)
* For the use case discussed,  you will create a profile name HRdb and config PostgresHRDB
* In doing so you will tell SCreator all about your HR database in our example
* Keep in mind due to ScAgent, the database may be on a host that is different than SCenter/SC servers

>  SCreator Admin/Control

* In ScServer setup itself, the desired profile/config has been setup and tested w/o DP Glue
* Set up a user in SCreator known as "scgluer", who can execute this profile/config job 
* SEE the "[ Security]" section below for scgluer user setup and why we do things this way
* The scgluer user in SCreator has a specific role and permissions dictated below

> SCenter to SCreator

* SCenter must have the DP Glue deployed as a WIN plugin
* It must be pushed out to the SCreator host by SCenter
* DP Glue (DPGLUE.EXE) will call SnapCreator.exe on the ScServe host when SCenter asks it
* DP Glue will only call quiesce and unquiesce on ScServe.
* The ScServe will be responsible for telling the ScAgent what needs to be done
* SCenter engine will be responsible for ensuring snapshot of the LUN where dp/app resides


> Syntax for the SCGL Module using "cx2sc"

* The DPGLUE\Readme_Before_Using.txt is assumed to have been read and understood.

-SCGL "-cx2sc-[q|u]-VersionID" "DescriptiveWord[:SC_Server:SC_Port:SC_Profile:SC_Config:SC_Policy]"

Where :

"q" is quiesce. Obviously use this as the PRE (before) SCenter activity. It simply calls SC to do its quiesce.
"Q" is like q but with verbosity for troubleshooting from CLI only. 
"u" is unquiesce. Obviously use this as the PRE (before) SCenter activity. 
"U" is u but with verbosity for troubleshooting from CLI only.

"DescriptiveWord" is chosen by user to describe the run e.g. HRDBhourlies

"VersionID" is a behavior modifier and in this version it is 1.

EXAMPLE:
	NOTE: This argument uses the "t" adjective which forces an errorcode to result
	
	-SCGL -cx2sc-t-2 "MyPlaydb:localhost:8443:cdotExpProfile:PocConfig:hourly"
    
    NOTE2: Something similiar to this is what would put into SCenter pre/post to force an error code of 1

There are additional arguments that are used for troubleshooting. See below.

You cannot run a whole ScServer backup/restore process with SCGL ... only unquiesce/quiesce and some listing
commands. You cannot restore with DPG either. THIS IS INTENTIONAL.


> Warnings !!!

* If you run SCGL as a pre-process to quiesce, then YOUR db/app stays quiesced until SCenter gets to running the post-process
* The length you are quiesced depends on what SCenter is backing up.
* Be forewarned, because having an app/db quiesced for long periods of time may not be advisable.
* Also, *if* SCenter successfully runs the pre-process but not the post-process, then your db\app could easily be stuck in quiesced mode UNTIL fixed by admin.
* Be aware that quiesce will do said to your app for the duration of the SCenter "backup" 
* so be conscious of the time your app/db will be in that state
* The long command line may not seem a huge improvement on using SnapCreator.exe with all its arguments. But it is.

[ Using with SCenter ]
 ---------------------------------

> Basic Steps

* Follow all directives found in DPGLUE\Readme_Before_Using.txt
* Ensure SCenter 3x is running in the environment
* Deploy DP Glue properly in plugin-mode into SCenter 
* DP Glue is for 64bit OS
* It is case sensitive

> The first argument

* The 1st command line argument required by SCenter
  as they correlate to DP Glue are described here:

	[-]-describe	this explains the plugin
    	- or -
    [-]-discover	not supported
        - or -
    [-]-quiesce		is supported
        - or -
    [-]-unquiesce	is supported
        - or -
    [-]-restore_pre is supported
        - or -
    [-]-restore_pre is supported
        - or -
    [-]-clone_pre	is supported
    	- or -
    [-]-clone_post  is supported


> Required Environment Key and Value Pairs for SCenter as plugin

* Ensure the following variables (in caps) are set within the SCenter
job so to be present for DP Glue in the runtime environment:

  DPG_SC_ARG1_MODULE_<???> set to Module name DUBR. No QUOTES.
 	- and -
  DPG_SC_ARG2_MODIFIER_<???> set to Modifier. See below. Double Quoted.
	- and -
  DPG_SC_ARG3_DATIVE_<???> set to Dative. See below. Double Quoted.

* Whereby the "_<???>" is replaced by one of these suffixes:

   _CPR as the suffix for when the 1st argument is --clone_pre
   _QUI as the suffix for when the 1st argument is --quiesce
   _UNQ as the suffix for when the 1st argument is --unquiesce
   _CPO as the suffix for when the 1st argument is --clone_post
   _RES as the suffix for when the 1st argument is --restore
   _RPR as the suffice for when the 1st argument is --restore_pre 

* The value for the DPG_SC_ARG1_MODULE_<???> key follows this guidance:
    - To use this sub-module you would set this value to SCGL with no quotations
    - case sensitive
    - for instance DPG_SC_ARG1_MODULE_QUI=SCGL

* The value for the DPG_SC_ARG2_MODIFIER_<???> key follows this guidance which was 
	explained above:
    - for this sub-module you would use below syntax in double quotes
      	"-cx2sc-[q|u]-VersionID" 
    - for instance DPG_SC_ARG2_MODIFIER_QUI="-cx2sc-q-1"

* The value for the DPG_SC_ARG3_DATIVE_<???> key follows this guidance:
    - for this sub-module you would use below syntax in double quotes
    - "DescriptiveWord[:SC_Server:SC_Port:SC_Profile:SC_Config:SC_Policy]"
    - the proper replacements to the above syntax was explained above


[ Using without SCenter ]
---------------------------------

* all syntax is the same except for these differences
* the first commandline argument is --run or -run
* the _<???> suffix is replaced with the _RUN
* and you run from command line not SC

[ Security]
---------------------------------

* NOTE WELL that in this just a 1.0 version there is NO encryption
* The password is buried in the code of the DP Glue programs
* In any case you need to do the following:

	Assuming the SCreator GUI Process is running

	Use a Supported browser to access the SC Server

	The administrator would open the SCreator GUI

	Using the URL similiar to https://localhost:8443/ui/

		Login in as the administrator

		Click on User and Roles
		Role Management
		Add
		Enter "SC_GLUE_ROLE"
		And a definition as desired
		Highight this new role
		Click Assign Permissions
		Pick these and move to right side
			Policy Viewer
			Custom
			RBAC View
		[SAVE]

		Click on User and Roles
		User Management
		Add
		Enter "scgluer"
		Enter "D0ntTrust1t!" as the password 
		(The default program password is "D0nTrust1t!" . More on the rudimentary security later. See LOW_SECURITY below)
		Highight this new user
		Click Assign Roles
		Pick this and move to right side
			SC_GLUE_ROLE
		[SAVE]

		For each profile 
		which will be utilized by SCenter
		Recommended that you
		Click User and Roles
		User Management
		Highlight scgluer
		Assign Profiles
		Pick only the applicable profiles
			To be determined by admin user
		[SAVE]

[ LOW_SECURITY ]

* There should be no illusions that this 1.0 version product is very secure
* Some candor is in order here
* As discussed above, the role in SnapCreator for DPG's cx2sc module is:
	SC_GLUE_ROLE
* That is the core of the security in that management of this role and
	what profiles\configs it can access are key
* In many ways this gives the SC Administrator control of the cx2sc module
* The default user in SC that has this SC_GLUE_ROLE is "scgluer" 
* And the default password is "D0ntTrust1t!"
* The "hard-coded" password is somewhat obfuscated in the program code
* But figuring it out from the code is possible
* You may change the "0" in the password (just the 0) to something else
* (Not that this is much of a help admittedly)
* To change that zero ... you would do the following:
	- rename the scglue_ao.luac file to scglue_aoOFF with no extension
	- you would create a new file scgluer_ao.lua with no "c" on the end
	- do NOT let notepad\editor put anything on the end of the file except ".lua"
	- inside the file you would put these contents, and change the 0 as explained below


		-- I CHANGED THIS PROGRAM EnterNameHere Date_DD-MON-YYYY
		-- DO NOT CHANGE THESE LINES OF CODE PLEASE below
		-- #############################################
		function SCAO__get_CodePw()
		-- DO NOT CHANGE THESE LINES OF CODE PLEASE above
		-- #############################################


		-- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		-- YOU MAY CHANGE 
		-- THE LINE BELOW TO ANY "3" LETTERS AND\OR NUMBERS
		-- 			BUT NO SPECIAL CHARACTERS PLEASE
		return "0"; -- ONLY CHANGE THIS LINE inside the double quotes
		-- please consult readme file for more information about making this change and the IMPACT!
		-- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


		-- DO NOT CHANGE THESE LINES OF CODE PLEASE below
		-- #############################################
		end
		-- DO NOT CHANGE THESE LINES OF CODE PLEASE above
		-- #############################################

[ TROUBLESHOOTING / CHECKING THE PLUMBING]
---------------------------------

* The DP Glue error codes / result codes conform to SCenter API when run in plugin-mode.
* This is makes the backup admin's task easier by greatly simplifying the troubleshooting
* Yet, error codes from the SCGL module itself are displayed before the SCenter codes are
* So too are the SCreator error codes.
* The DPG command and resulting output can be given by the backup admin to SCreatore team
* DPGLUE.EXE --run may be used from command-line to *carefully* trouble shoot in TEST-only lab
* DPG is using specific error codes based on what is happening with SC
* And when the SC team runs the command that backup admin is using, they will see SC output
* Again ONLY run from command line if you need to troubleshoot in lab en

* Here are some basic troubleshooting arguments (EXAMPLES). 
	

    ("-cx2sc-V-1")
	NOTE: This argument uses the "V" adjective which checks on the list of volumes for this profile\config
	e.g. SCGL -cx2sc-V-1 MyPlaydb:localhost:8443:cdotExpProfile:PocConfig:hourly

	("-cx2sc-BS-1")
	NOTE: This argument uses the "BS" adjective which does a list of backup handled by ScServer.
	e.g. SCGL -cx2sc-sp-1 MyPlaydb:localhost:8443:cdotExpProfile:PocConfig:hourly

	("-cx2sc-D-1")
	NOTE: This argument uses the "D" adjective which does an ScAgent discovery activity
	e.g. SCGL -cx2sc-D-1 MyPlaydb:localhost:8443:cdotExpProfile:PocConfig:hourly

	("-cx2sc-ERR-1")
	NOTE: This argument uses the "ERR" adjective which forces an errorcode to result
			which matches the number following the "ERR" in this way
	e.g. SCGL -cx2sc-ERR-201 MyPlaydb:localhost:8443:cdotExpProfile:PocConfig:hourly
	NOTE1:	This will cause SCGL to error out with a code of 201.
	NOTE2:  You may change 201 to any positive number or even 0 for success

	("-fyiTS")
	NOTE: This argument gives one important information about this release. Will error out purposely.
	e.g. SCGL -fyiTS

#####################################CONCLUSION##################################

[ NOTE WELL ]
---------------------------------
SnapCreator, SnapProtect & SnapCenter are products from NetApp.
PostgreSQL is 3rd party example see www.postgres.org

#####################################END#########################################
Document was revised on 05-FEB-2018. Content is dated, deprecated, not maintained.
#################################################################################