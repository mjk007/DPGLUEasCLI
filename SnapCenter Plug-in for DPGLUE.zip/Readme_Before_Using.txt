#########################################################################
			>> This document may have unintentional errors. <<
#########################################################################
#########################################################################

Primary Readme Information 
								
for 

SnapCenter Plugin for DP Glue v1.12 aka 1.1.2

#########################################################################

This is released a Community Tool on as-is basis.

#########################################################################

Plug-in mode means DP GLUE running with SnapCenter. CLI or stand-alone 
command-line mode mean DP GLUE run by hand, another scheduler and 
not run by SnapCenter. 

Both are supported. CLI version is 1.1.2, while Plugin-mode is 
version 1.12.

#########################################################################

Please see the Readme_Before_Using.pdf for the rest of this documentations