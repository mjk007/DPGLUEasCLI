#########################################################################
				>> This document is not error-free. <<
#########################################################################
#########################################################################

					Secondary Readme Information 
								
								for 

				The SCGL Module's "sc2sp" Sub-module

							when using

  			with SnapCenter Plugin for DP Glue v.1.x untested

##########################################################################

THIS WAS DEPRECATED in the PREVIOUS VERSION OF DP Glue.
IT IS NO LONGER TESTED. IT IS NO LONGER MAINTAINED.
	
#########################################################################

.
	The name "sc2sp" abbreviates for SnapCenter 
	to SnapProtect interface.
.

#########################################################################


This is the Readme File for "SCGL" program and specifically
its sub-module "sc2sp", which allows for SnapCenter to call legacy
SnapProtect jobs using its SP10's native scripts.

SnapCenter execution of this sub-module will result in the error codes expected
by the product's API. 

#################################################################################

Although this sub-module's function will become less important as end-users
transition to SnapCenter, it is hoped that for now SnapCenter can utilize it
to run SnapProtect 10 jobs.

This sub-module simply executes SnapProtect pre-configured jobs from 
command-line on the WIN hosts using DP Glue in plugin mode by SnapCenter.
It uses SnapProtect executables on CmSrv meant for this purpose.

This extends the capabilities of SnapCenter as a single data protection
 dashboard

################################################################################# 

To understand this document, first read :

	DPGLUE\SC_GLUE\README_BEFORE_USING.txt

#################################################################################


[ TERMS ]
---------------------------------

* DP Glue, DPG are synonymous
* SP, SnapProtect, SP10 and SP11 are synonymous
* SC, SnapCenter are synonymous

[ Conceptual Architecture ]
---------------------------------

> Situation

* Your environment has been SnapCenter driven for years
* But, you have received SnapProtect license for a "FILER"
* Unable to convert to SP, or not willing to, you want SC to control SP
* So, you have a FlexVol that has an SC plugin Database like PostgreSQL
* And SC control's the quiesce and unquiesce of the DB with its plugin
* But SC calls DPG to have SP snapshot the FlexVol & place in its catalog
* The power of SP's catalog and reporting ... and even aux copies
* All with SC in control with DPG as the go between

> Approach

* You would install on the CommServe:
	SnapCenter 4.2.x, 
	SnapProtect 10 or 11
	& DP GLUE
* You will need to use a special user (created by Admin) in SP
* More on this user later

> Workflow

* Assuming all is installed correctly
* You would create a SC plugin job (profile/config) i.e. PostgreSQL
* Which is tied to a "SC plug-in" Database/App i.e. PostgreSQL
* The workflow would be that SC Server runs a profile/config
* Because it is a PLUGIN i.e. PostgreSQL it MUST be run through an agent
* The agent quiesces the Database/app
* the agent executes the DPG commands provided to it from the config
* typically this means DPG will have to login to SP as scgluer user
* then DPG will tell SP to run an xml script that runs a subclient 
* the subclient is part of a NAS Client
* so it takes a snapshot of a NetApp FlexVol
* DPG then logs out of SP
* SC agent takes over again and unquiesces the Database/App
* and the SC server completes
* now if the DPG and SP interraction failed, SC will receive that error code back
*
* IMPORTANT......
* Do not set DPG as the SC Plugin ... !
* you would set up a NAS Client Backup in SP for the same FlexVol that DB is on
* this permits SP to have a job that does the snapshot (and whatever else like AUX copies)
* Read on to learn the arguments to use

> Caution

* The challenge to consider is HOW LONG the database will be in quiesced mode
* given what SnapProtect itself must get done
* TEST TEST TEST TEST
* and Prove you are getting valid backups 
* this is why current version is best in non-production modes


 [ INTEGRATION of DP Glue ]
 ---------------------------------

> Basic Steps

* Recall sc_glue's contents have been manually copied to a new subdirectory "plugins\DPGLUE" under the SC Server 4.1+
* Ensure that SP and SC Server 4.1 are both running on the same system as you have "installed" DP Glue
* DPG does not run as a service
* It does not listen on any ports
* It does not need to be installed on hosts that you just have SC agents on 


> SP Admin/Control

* ensure that in SP Server there is a user who can run the profile/config you want known 
* this user is known as "scgluer" 
* SEE the "[ SP to SC Security]" section below for scgluer user setup and why we do things this way
* The scgluer user in SP has a specific role and permissions dictated below

> SP plus SC

* ensure both SP and SC can access and exec the dir and contents of DPGLUE
* the program to run is DPGLUE.EXE
* NEVER RUN THESE OPTIONS FROM THE COMMAND LINE -- THEY ARE MEANT TO BE RUN BY SC itself

> Syntax DPGLUE.EXE for the Module "sc2sp"

* Syntax to use in SC as plugin mode. Do not use as CLI unless you are troubleshooting.

-SCGL -sc2sp-[qln|gjl|runx|qlo|qloall]-VersionID "DescriptiveWord:-:-:-:-:-:-:"

Where :

"runx" refers to run an xml script that SP Admin has given the SC Admin to run. 
		In this case the format of the 2nd argument would be
	  	"DescriptiveWord:<CommServerHostname>:<XML SCRIPT NAME>:-:-:-:-:"
	  	It will run as scgluer user the XML script if you have placed that
	  	scripted in the DPGLUE\sc_glue\var directory and prefixed the
	  	scripts name wiht "sc2sp_".

"gjl" refers to q script call to get a list of job status for a subclient. 
	  	In this case the format of the 2nd argument would be
	  	"DescriptiveWord:<CommServerHostname>:<SubClientName>:-:-:-:-:"
	  	It will do so as the scgluer user.

"qln" refers to q log in. In this case the format of the 2nd argument would be
	  	"DescriptiveWord:<CommServerHostname>:<CS_ClientName>:-:-:-:-:"
	  	It will login as scgluer user.

"qlo" refers to q log out. In this case the format of the 2nd argument would be
	  	"DescriptiveWord:<CommServerHostname>:-:-:-:-:-:".

"qloall" refers to q log out all. In this case the format of the 2nd argument would be
	  	"DescriptiveWord:<CommServerHostname>:<CS_ClientName>:-:-:-:-:"
	  	It will logout all users on the host it is running on.

Note: the "runx" operation assumes a login of scgluer has occurred already

Note2: these commands are run by placing them in the SC config file, not commandline

Note3: in this version, all "VersionIDs" should be 1.


> How to set up the SC Profile/Config

* There are literally many ways to do so
* But, in any case, do NOT use DPG as variables in the config for PLUGIN
* In this way, even if you are using an SC Plugin to quiesce and unquiesce
* You also get DPG to help you get a SnapShot taken by SP
* And with this SP's catalogs and aux copies

* In testing we simply used these kind of variable values
		PRE_NTAP_CMD01="C:\Program Files\NetApp\Snap_Creator_Framework\scAgent4.1P1\plugins\DPGLUE\sc_glue\DPGLUE.EXE" _NOQUOTES_see above for Q LogIn Arg_NOQUOTES
		
		PRE_APP_QUIESCE_CMD01="C:\Program Files\NetApp\Snap_Creator_Framework\scAgent4.1P1\plugins\DPGLUE\sc_glue\DPGLUE.EXE" NOQUOTES_see above for runx Arg_NOQUOTES
		
		POST_APP_UNQUIESCE_CMD01="C:\Program Files\NetApp\Snap_Creator_Framework\scAgent4.1P1\plugins\DPGLUE\sc_glue\DPGLUE.EXE" NOQUOTES_see above for Q Logout Arg_NOQUOTES

		Also, we did not test the merits of NTAP_USE_EXTERNAL_SNAPSHOT ... NTAP_SNAPSHOT_CREATE_CMD01=........ nor NTAP_SNAPSHOT_NODELETE
		

> Warnings !!!

* If you run SCGL so that a call is made to SP, then this can elongate the period in which your app/plugin is quiesced
* The length you are quiesced depends on what SP is backing up.
* Be forewarned, because having an app/db quiesced for long periods of time may not be advisable.
* In this version the output is to the terminal session NOT a log file. This includes SC commandline output.


[ Using with SCenter ]
 ---------------------------------

> Basic Steps

* Follow all directives found in DPGLUE\Readme_Before_Using.txt
* Ensure SCenter 3x is running in the environment
* Deploy DP Glue properly in plugin-mode into SCenter 
* DP Glue is for 64bit OS
* It is case sensitive

> The first argument

* The 1st command line argument required by SCenter
  as they correlate to DP Glue are described here:

	[-]-describe	this explains the plugin
    	- or -
    [-]-discover	not supported
        - or -
    [-]-quiesce		is supported
        - or -
    [-]-unquiesce	is supported
        - or -
    [-]-restore_pre is supported
        - or -
    [-]-restore_pre is supported
        - or -
    [-]-clone_pre	is supported
    	- or -
    [-]-clone_post  is supported


> Required Environment Key and Value Pairs for SCenter as plugin

* Ensure the following variables (in caps) are set within the SCenter
job so to be present for DP Glue in the runtime environment:

  DPG_SC_ARG1_MODULE_<???> set to Module name SCGL. No QUOTES.
 	- and -
  DPG_SC_ARG2_MODIFIER_<???> set to Modifier. See below. Double Quoted.
	- and -
  DPG_SC_ARG3_DATIVE_<???> set to Dative. See below. Double Quoted.

* Whereby the "_<???>" is replaced by one of these suffixes:

   _CPR as the suffix for when the 1st argument is --clone_pre
   _QUI as the suffix for when the 1st argument is --quiesce
   _UNQ as the suffix for when the 1st argument is --unquiesce
   _CPO as the suffix for when the 1st argument is --clone_post
   _RES as the suffix for when the 1st argument is --restore
   _RPR as the suffice for when the 1st argument is --restore_pre 

* The value for the DPG_SC_ARG1_MODULE_<???> key follows this guidance:
    - To use this sub-module you would set this value to SCGL with no quotations
    - case sensitive
    - for instance DPG_SC_ARG1_MODULE_QUI=SCGL

* The value for the DPG_SC_ARG2_MODIFIER_<???> key follows this guidance which was 
	explained above:
    - for this sub-module you would use below syntax in double quotes
      	-sc2sp-[qln|gjl|runx|qlo|qloall]-VersionID 
    - for instance DPG_SC_ARG2_MODIFIER_QUI="-sc2sp-runx-1"

* The value for the DPG_SC_ARG3_DATIVE_<???> key follows this guidance:
    - for this sub-module you would use below syntax in double quotes
    - "DescriptiveWord:-:-:-:-:-:-:"
    - the proper replacements to the above syntax was explained above


[ Using without SCenter ]
---------------------------------

* all syntax is the same except for these differences
* the first commandline argument is --run or -run
* the _<???> suffix is replaced with the _RUN
* and you run from command line not SC






[ SP to SC Security]
---------------------------------

* NOTE WELL that in this just a 1.1 version there is NO encryption
* The password is buried in the bytcode of the DPG programs
* BUT THIS FACT does not make it unreadable
* However, this is just a 1.0 version of course. 
* In any case you need to do the following:
		[Work with the SP admin to add a user called scgluer.]
		[Currently this user must have all Admin rights]
		[Ensure the user is tied to the subclients related to DPG]
		[The password for this users is explained in the next section]

[ LOW_SECURITY ]

* There should be no illusions that this 1.1 version product is very secure
* The user in SP that is needed by DP GLUE is "scgluer"
* And the default password is "D0ntTrust1t!"
* The "hard-coded" password is somewhat obfuscated in the program code
* But figuring it out from the code is possible
* You may change the "0" in the password (just the 0) to something else
* (Not that this is much of a help admittedly)
* To change that zero ... you would do the following:
	- rename the scglue_ao.luac file to scglue_aoOFF with no extension
	- you would create a new file scgluer_ao.lua with no "c" on the end
	- do NOT let notepad\editor put anything on the end of the file except ".lua"
	- inside the file you would put these contents, and change the 0 as explained below


		-- I CHANGED THIS PROGRAM EnterNameHere Date_DD-MON-YYYY
		-- DO NOT CHANGE THESE LINES OF CODE PLEASE below
		-- #############################################
		function SCAO__get_CodePw()
		-- DO NOT CHANGE THESE LINES OF CODE PLEASE above
		-- #############################################


		-- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		-- YOU MAY CHANGE 
		-- THE LINE BELOW TO ANY "3" LETTERS AND\OR NUMBERS
		-- 			BUT NO SPECIAL CHARACTERS PLEASE
		return "0"; -- ONLY CHANGE THIS LINE inside the double quotes
		-- please consult readme file for more information about making this change and the IMPACT!
		-- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


		-- DO NOT CHANGE THESE LINES OF CODE PLEASE below
		-- #############################################
		end
		-- DO NOT CHANGE THESE LINES OF CODE PLEASE above
		-- #############################################

[ TROUBLESHOOTING / CHECKING THE PLUMBING]
---------------------------------
* When executed by SnapCenter the result / error codes will
	match the API of the product, because DP Glue conforms
	to them.
* In the output of the execution, however, more details
	are shown as to execution success or failure.
* This is accomplished by way of text & numerical positions
	in the code shown in the format that is expected 
	by SnapCenter. This means they will appear in SCenter
	logs too.  
* Each one of these "code positions" is at a specific step 
	in the process.
* This is makes the backup admin's task easier by greatly 
	simplifying the troubleshooting

* Here are some unsupported troubleshooting arguments (EXAMPLES). 

	("-sc2sp-T-1")
	NOTE_: This argument uses the "T" adjective which tests some key aspects of whether scglue can access the OS
	NOTE2: you will get error on some OS cause errorlevel is not zero always on simple echo
	e.g. scglue -sc2sp-T-1 "MyPlaydb:-:-:-:-:-"

	("-sc2sp-ERR-1")
	NOTE: This argument uses the "ERR" adjective which forces an errorcode to result
			which matches the number following the "err-" in this way
	e.g. scglue -sc2sp-err-201 "MyPlaydb:-:-:-:-:-"
	NOTE2:	This will cause scglue to error out with a code of 201.
	NOTE3:  You may change 201 to any positive number or even 0 for success

	("-fyiTS")
	NOTE: This argument gives one important information about this release. Not exciting.
	e.g. scglue -fyiTS

#####################################CONCLUSION##################################

[ NOTE WELL ]
---------------------------------

SnapCenter, SnapProtect & SnapCreator are products from NetApp.

#####################################END#########################################
Document was revised on 05-FEB-2018. Content is dated, deprecated, not maintained.
#################################################################################