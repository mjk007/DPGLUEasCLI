# Role is trivial and elective
# new v1.1.2 aka 112 shim for ease of use of DPG
# MjK 
write-host "This is not enabled at this time"