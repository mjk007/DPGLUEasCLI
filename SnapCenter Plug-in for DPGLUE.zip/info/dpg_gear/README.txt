"Do Not Delete Anything in this directory." 
