# new v1.1.2 shim to EOS as part of DPGLUE
# do not execute manually!
# MjK w/ initial guidance KP
# Purpose of this program is for DPG to use WIN PS to call FS Flushing
# Only DRIVELETTERS supported
# NOTE: EXTERNALLY calling https://docs.microsoft.com/en-us/sysinternals/downloads/sync namely sync64.exe is assumed to be installed at \Program Files\sync\sync64.exe
# NOTE: for LIN EXTERNALLY Calling sync 

$var_str_TARGET=$args[0]
$var_str_USERNAME=$args[1]
$var_str_PWD=$args[2]
$var_str_MYVOL=$args[3]
$var_str_MYDRIVELETTER=$args[4]
$var_str_MYACTION=$args[5]

If ($var_str_MYACTION  -eq '-dpgH') #say hello
{
	
	write-host "hello. OK-dpg."
	exit 0

}
ElseIf ($var_str_MYACTION  -eq '-dpg0WIN') #Test of presence of the 3rd party tool
{
	Try 
	{
		write-host "Looking for presence and testing of MS downloadable tool to Flush Filesystem."
		& "\Program Files\sync\sync64.exe" "-nobanner" "-h"
		write-host "Flush operation help output was used to try to find \Program Files\sync\sync64.exe."
		write-host "Operation attempted. OK-dpg."
		exit 0
	}
	Catch
	{
		write-host "Did not find the sync64 required tool or attempt itself failed. ERROR-dpg."
		write-host "Only use crash consistent method of EOS snap without filesystem sync to avoid failures."
		exit 1

	}
}
ElseIf ($var_str_MYACTION  -eq '-dpg1WIN') #run 3rd party tool
{
	Try 
	{
		write-host "Attempting to Flush Filesystem tool three times with 1 sec sleep in between."
		& "\Program Files\sync\sync64.exe" "-nobanner" "$var_str_MYDRIVELETTER"
		write-host "Operation attempted. 1 of 3. OK-dpg."
		sleep 1
		& "\Program Files\sync\sync64.exe" "-nobanner" "$var_str_MYDRIVELETTER"
		write-host "Operation attempted. 2 of 3. OK-dpg."
		sleep 1
		& "\Program Files\sync\sync64.exe" "-nobanner" "$var_str_MYDRIVELETTER"
		write-host "Operation attempted. 3 of 3."
		write-host "3 flush operations called. OK-dpg."
		exit 0
	}
	Catch
	{
		write-host "Flush operation was attempted using a program called sync64.exe; however, it failed."
		write-host "Only use crash consistent method of EOS snap without filesystem sync to avoid failures."
		write-host "Operation did not occur properly. ERROR-dpg."
		exit 1

	}
}
ElseIf ($var_str_MYACTION  -eq '-dpg0LIN') #Test of presence of the 3rd party tool
{
	Try 
	{
		write-host "Looking for presence and testing of OS Linux sync tool Flush Filesystem."
		& sync --help
		write-host "Flush operation help output was used to try to find the sync tool."
		write-host "Operation attempted. OK-dpg."
		exit 0
	}
	Catch
	{
		write-host "Did not find the OS sync tool or attempt itself failed. ERROR-dpg."
		write-host "Only use crash consistent method of EOS snap without filesystem sync to avoid failures."
		exit 1

	}
}
ElseIf ($var_str_MYACTION  -eq '-dpg1LIN') #run 3rd party tool
{
	Try 
	{
		# sync
		write-host "Attempting to Flush Filesystem tool three times with 1 sec sleep in between."
		& sync
		write-host "Operation attempted. 1 of 3. OK-dpg."
		sleep 1
		& sync
		write-host "Operation attempted. 2 of 3. OK-dpg."
		sleep 1
		& sync
		write-host "Operation attempted. 3 of 3. OK-dpg."
		write-host "3 flush operations called. OK-dpg."
		exit 0
	}
	Catch
	{
		write-host "Flush operation was attempted using a program called sync; however, it failed."
		write-host "Only use crash consistent method of EOS snap without filesystem sync to avoid failures."
		write-host "Operation did not occur properly. ERROR-dpg."
		exit 1

	}
}
Else 
{
		write-host "Do not execute this program manually."
		exit 1

}
Exit 0

