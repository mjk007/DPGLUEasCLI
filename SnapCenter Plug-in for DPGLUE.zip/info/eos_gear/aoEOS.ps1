# new v1.1.2 shim to EOS as part of DPGLUE
# do not execute manually!
# MjK w/ initial guidance KP
# Purpose of this program is for DPG to use WIN PS to Invoke a Web Request with specific behaviors tied to Element 11



$var_str_TARGET=$args[0]
$var_str_USERNAME=$args[1]
$var_str_PWD=$args[2]
$var_str_MYVOL=$args[3]
$var_str_MYSNAP=$args[4]
$var_str_SFCALL=$args[5]
$var_str_SFCALLPARAMS=$args[6]  
$var_int_OUTPUTMODE=$args[7] #if no arg given still will proceed

$var_str_ALL=""
$var_wob_OUTPUT=""
$var_str_MADESTRING=""
$var_str_PREPAREDOUTPUT=""
$var_str_DELIMS="[{]}`""
$var_str_Temp0="";
$var_str_Temp1="";
$var_str_Temp2="";
$var_int_RETCODE=1;

If ($var_str_USERNAME  -ne '_b64e') 
{

	$var_str_CREDS = $var_str_USERNAME + ":" + $var_str_PWD
	$var_str_AUTHSTRING=[System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($var_str_CREDS))

}  
Else 
{

	$var_str_AUTHSTRING = $var_str_PWD

} 

# Vars/Values that are defaults
	# Below is merely the default ... it may be overwritten as a var in particular case below
$var_str_ALL="Invoke-WebRequest -header @{`"accept`" = `"application/json`"; `"authorization`" = `"Basic $var_str_AUTHSTRING`" } -method POST -uri https://$var_str_TARGET/json-rpc/$var_str_SFVERSION -Body '{`"method`" : `"$var_str_SFCALL`", `"params`": { $var_str_SFCALLPARAMS } }'" 
$var_str_SFVERSION="10.3"

sleep 1

# TEST OFF write-host $var_str_ALL 




If ($var_int_OUTPUTMODE  -eq '-dpgH') # pattern recognition test
{

	write-host "hello"
	$var_int_RETCODE=0	

}
ElseIf ($var_int_OUTPUTMODE  -eq '-r') # if True show raw
{

	Invoke-Expression $var_str_ALL 
	$var_int_RETCODE=0	

}
ElseIf ($var_int_OUTPUTMODE  -eq '-f') # if True run and do basic formatting of out put
{
	$var_wob_OUTPUT = Invoke-Expression $var_str_ALL 
	$var_str_MADESTRING = $var_wob_OUTPUT.ToString()
	$var_str_PREPAREDOUTPUT=$var_str_MADESTRING.Split($var_str_DELIMS).replace(",","`n").replace(":","=")
	write-host $var_str_PREPAREDOUTPUT
	$var_int_RETCODE=0
}
ElseIf ($var_int_OUTPUTMODE  -eq '-dpg0') # Just show Invocation text .... legacy
{

	write-host $var_str_ALL 
	write-host "OK-dpg"
	$var_int_RETCODE=0	

}
ElseIf ($var_int_OUTPUTMODE  -eq '-dpg0WIN') # try GET API
{

	write-host $var_str_ALL 
	write-host "OK-dpg"
	$var_int_RETCODE=0	

}
ElseIf ($var_int_OUTPUTMODE  -eq '-dpg0LIN') # try GET API
{
	write-host $var_str_ALL 
	write-host "OK-dpg"
	$var_int_RETCODE=0	

}
ElseIf ($var_int_OUTPUTMODE  -eq '-dpg1WIN') # if true run
{
	Try
	{
		$var_str_SFVERSION="10.3"
		$var_str_ALL="Invoke-WebRequest -SkipCertificateCheck -header @{`"accept`" = `"application/json`"; `"authorization`" = `"Basic $var_str_AUTHSTRING`" } -method POST -uri https://$var_str_TARGET/json-rpc/$var_str_SFVERSION -Body '{`"method`" : `"$var_str_SFCALL`", `"params`": { $var_str_SFCALLPARAMS } }'" 
		write-host $var_str_ALL

		
		$var_wob_OUTPUT = Invoke-Expression $var_str_ALL #hide output	
		$var_str_MADESTRING = $var_wob_OUTPUT.ToString()
		$var_str_Temp0=$var_str_MADESTRING.Split(":")[0].Split("`"")[1]
		$var_str_Temp1=$var_str_MADESTRING.Split(":")[2].Split(",")[0].Split($var_str_DELIMS)
		$var_str_Temp2 = "WebCall_result.." + $var_wob_OUTPUT.StatusDescription.ToString() + "." + $var_wob_OUTPUT.StatusCode.ToString() + ";"
		If ( $var_str_Temp0 -eq 'error' )
		{
			$var_int_RETCODE=3
			$var_str_Temp2 = $var_str_Temp2 +  "EOS_result.." + $var_str_Temp0 + ".." + $var_str_Temp1 + "..;..Overall_return.._" +  $var_int_RETCODE + "_..;ERROR-dpg;"

		}
		Else
		{
			$var_int_RETCODE=0
			$var_str_Temp2 = $var_str_Temp2 +  "EOS_result..OK..0" +  "..;..Overall_return.._" +  $var_int_RETCODE + "_..;OK-dpg;"
		}
	}
	Catch
	{
		$var_int_RETCODE=2
		$var_str_Temp2 = "WebCall_result.." + "BAD" + "." + 1 + ";" + "EOS_result.." + "unknown" + ".." + "1" + "..;..Overall_return.._" +  $var_int_RETCODE + "_..;ERROR-dpg;"	
	}
	write-host $var_str_Temp2
	# do not set return code here	
}
ElseIf ($var_int_OUTPUTMODE  -eq '-dpg1LIN') # if true run
{
	Try
	{
		$var_str_SFVERSION="10.3"
		$var_str_ALL="Invoke-WebRequest -SkipCertificateCheck -header @{`"accept`" = `"application/json`"; `"authorization`" = `"Basic $var_str_AUTHSTRING`" } -method POST -uri https://$var_str_TARGET/json-rpc/$var_str_SFVERSION -Body '{`"method`" : `"$var_str_SFCALL`", `"params`": { $var_str_SFCALLPARAMS } }'" 
		$var_wob_OUTPUT = Invoke-Expression $var_str_ALL #hide output	
		$var_str_MADESTRING = $var_wob_OUTPUT.ToString()
		$var_str_Temp0=$var_str_MADESTRING.Split(":")[0].Split("`"")[1]
		$var_str_Temp1=$var_str_MADESTRING.Split(":")[2].Split(",")[0].Split($var_str_DELIMS)
		$var_str_Temp2 = "WebCall_result.." + $var_wob_OUTPUT.StatusDescription.ToString() + "." + $var_wob_OUTPUT.StatusCode.ToString() + ";"
		If ( $var_str_Temp0 -eq 'error' )
		{
			$var_int_RETCODE=3
			$var_str_Temp2 = $var_str_Temp2 +  "EOS_result.." + $var_str_Temp0 + ".." + $var_str_Temp1 + "..;..Overall_return.._" +  $var_int_RETCODE + "_..;ERROR-dpg;"

		}
		Else
		{
			$var_int_RETCODE=0
			$var_str_Temp2 = $var_str_Temp2 +  "EOS_result..OK..0" +  "..;..Overall_return.._" +  $var_int_RETCODE + "_..;OK-dpg;"
		}
	}
	Catch
	{
		$var_int_RETCODE=2
		$var_str_Temp2 = "WebCall_result.." + "BAD" + "." + 1 + ";" + "EOS_result.." + "unknown" + ".." + "1" + "..;..Overall_return.._" +  $var_int_RETCODE + "_..;ERROR-dpg;"	
	}
	write-host $var_str_Temp2
	# do not set return code here	
}
ElseIf ($var_int_OUTPUTMODE  -eq '-dpg1') # if true run LEGACY
{
	Try
	{
		$var_wob_OUTPUT = Invoke-Expression $var_str_ALL #hide output	
		$var_str_MADESTRING = $var_wob_OUTPUT.ToString()
		$var_str_Temp0=$var_str_MADESTRING.Split(":")[0].Split("`"")[1]
		$var_str_Temp1=$var_str_MADESTRING.Split(":")[2].Split(",")[0].Split($var_str_DELIMS)
		$var_str_Temp2 = "WebCall_result.." + $var_wob_OUTPUT.StatusDescription.ToString() + "." + $var_wob_OUTPUT.StatusCode.ToString() + ";"
		If ( $var_str_Temp0 -eq 'error' )
		{
			$var_int_RETCODE=3
			$var_str_Temp2 = $var_str_Temp2 +  "EOS_result.." + $var_str_Temp0 + ".." + $var_str_Temp1 + "..;..Overall_return.._" +  $var_int_RETCODE + "_..;ERROR-dpg;"

		}
		Else
		{
			$var_int_RETCODE=0
			$var_str_Temp2 = $var_str_Temp2 +  "EOS_result..OK..0" +  "..;..Overall_return.._" +  $var_int_RETCODE + "_..;OK-dpg;"
		}
	}
	Catch
	{
		$var_int_RETCODE=2
		$var_str_Temp2 = "WebCall_result.." + "BAD" + "." + 1 + ";" + "EOS_result.." + "unknown" + ".." + "1" + "..;..Overall_return.._" +  $var_int_RETCODE + "_..;ERROR-dpg;"	
	}
	write-host $var_str_Temp2
	# do not set return code here	
}
ElseIf ($var_int_OUTPUTMODE  -eq '-sWIN') # if true run

{

       Try

{

       $var_str_SFVERSION="10.3"

       $var_str_ALL="Invoke-WebRequest -header @{`"accept`" = `"application/json`"; `"authorization`" = `"Basic $var_str_AUTHSTRING`" } -method POST -uri https://$var_str_TARGET/json-rpc/$var_str_SFVERSION -Body '{`"method`" : `"$var_str_SFCALL`", `"params`": { $var_str_SFCALLPARAMS } }'"

       $var_wob_OUTPUT = Invoke-Expression $var_str_ALL

       $var_str_MADESTRING = $var_wob_OUTPUT.ToString()

       $var_str_PREPAREDOUTPUT=$var_str_MADESTRING.Split($var_str_DELIMS).replace(",","`n").replace(":","=")

       write-host $var_str_PREPAREDOUTPUT

       $var_int_RETCODE=0

 

}

       Catch

{

$var_int_RETCODE=2

}

       # do not set return code here

}
Else
{

	write-host Syntax used is not supported. This program should only be used by DP GLUE program suite.
	$var_int_RETCODE=0

}

# clean
$var_str_ALL=""
$var_wob_OUTPUT=""
$var_str_MADESTRING=""
$var_str_PREPAREDOUTPUT=""
$var_str_DELIMS="`""
$var_str_Temp0="";
$var_str_Temp1="";
$var_str_Temp2="";

sleep 2

exit $var_int_RETCODE