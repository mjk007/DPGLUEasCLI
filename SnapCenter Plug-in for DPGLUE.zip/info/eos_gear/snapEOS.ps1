# new v1.1.2 shim to EOS as part of DPGLUE
# do not execute manually!
# MjK w/ initial guidance KP
# Purpose of this program is for DPG to use WIN PS to SF lib to snap element volume

$var_str_TARGET=$args[0]
$var_str_USERNAME=$args[1]
$var_str_PWD=$args[2]
$var_str_MYVOL=$args[3]
$var_str_MYSNAP=$args[4]
$var_int_MYHOURS=$args[5]

If ($var_str_TARGET  -eq '-dpgH') #say hello
{
	
	write-host "hello"
	exit 0

}
Else
{
	Try 
	{
		$var_str_MYDURATION = $var_int_MYHOURS + ":00:00"
		write-host "Connecting to SF Cluster"
		Connect-SFCluster -Target $var_str_TARGET -UserName $var_str_USERNAME -Password $var_str_PWD
		write-host "Connected"
		write-host "Listing information about the SF Volume Desired"
		Get-SFVolume -Name $var_str_MYVOL
		write-host "Making a snapshot of the SF Volume Desired"
		Get-SFVolume -Name $var_str_MYVOL | New-SFSnapshot -Name $var_str_MYSNAP -Retention "$var_str_MYDURATION"
		write-host "SF Cluster snap occurred."
		write-host "OK-dpg."
		exit 0
	}
	Catch
	{

		write-host "SF Cluster snap cannot be confirmed due to way that PS cmdlet works."
		write-host "Still ending with positive return code. Check manually for snap."
		write-host "OK-dpg."
		exit 0

	}
}
exit 0



