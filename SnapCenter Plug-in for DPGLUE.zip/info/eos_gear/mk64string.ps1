# new v1.1.2 shim to EOS as part of DPGLUE
# do not execute manually!
# MjK w/ initial guidance KP
# Purpose of this program is for DPG to electively mod a PWD from clear text to base64 encoding prior to using the PWD

$var_str_ARGUMENT=$args[0]

$var_str_Converted=[System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($var_str_ARGUMENT))
write-host "No Errors. Result is ::$var_str_Converted:: between two colons on each side of this string. "
write-host "To be Error free, you would use this string as a password for a username of _b64e to connect to EOS."

