#########################################################################
      >> This document may have unintentional errors. <<
#########################################################################
#########################################################################

            		Readme Information 
            								
            			for 

            	the DUBR Module's "ln2sf" Sub-module

            		   when using

    SnapCenter Plugin for DP Glue v.1.1.3 aka 1.13

#########################################################################

The name "ln2sf" abbreviates for Local Node (replication)
to SolidFire (iSCSI LUN) aka Element

#########################################################################

This is the Readme File for "DUBR" module and specifically
its sub-module "ln2sf", which allows for SnapCenter to 
protect directories and files located on Windows and Linux
servers that are not using NetApp data management protects.

The sub-module transports data from such servers (aka hosts) to 
NetApp storage solution such as ONTAP, StorageGRID NAS Gateways,
and HCI/Element systems.

The purpose is to allow SnapCenter / Data Fabric benefits for
critical host files locally stored on hosts. An example of such
files would be DB dump files. Also for files under a particular 
directory on hosts. Lastly, directories and files under path.

#################################################################################

Goal of this Sub-module is to
provide for local hosts to use SolidFire VOL-iSCSI as LUN target to replicate 
their Direct Attached Storage (“DAS”) filesystems to. This is the “ln2sf” sub-module 
of  the DUBR module.

#################################################################################

Note

      * This sub-module is equivalent to ln2on
      * Please use the Readme file associated with ln2on
      * It is in this same directory


#################################################################################


[ CALLOUTS ]
---------------------------------

* There is no incremental or differential capability yet
* There is no promise that this document does not have mistakes
* There could be errors in this doc or in the software that could lose data
* TEST and use with care


#####################################CONCLUSION##################################

[ NOTE WELL ]
---------------------------------
SnapCreator, SnapCenter & SnapProtect are products from NetApp.
NetApp Data Fabric is from NetApp as well.
PostgreSQL is 3rd party example see www.postgres.org

#####################################END#########################################
This document was revised on 23-APR-2020. Content may be dated.
#################################################################################

