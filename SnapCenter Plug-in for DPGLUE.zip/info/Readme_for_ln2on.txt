#########################################################################
      >> This document may have unintentional errors. <<
#########################################################################
#########################################################################

            					Readme Information 
            								
            								for 

            	the DUBR Module's "ln2on" Sub-module

            							when using

    SnapCenter Plugin for DP Glue v.1.1.2 aka 1.12 or 1.1P2

#########################################################################

The name "ln2on" abbreviates for Local Node (replication)
to NetApp ONTAP (NAS).

#########################################################################

This is the Readme File for "DUBR" module and specifically
its sub-module "ln2on", which allows for SnapCenter to 
protect directories and files located on Windows and Linux
servers that are not using NetApp data management protects.

The sub-module transports data from such servers (aka hosts) to 
NetApp storage solution such as ONTAP, StorageGRID NAS Gateways,
and HCI/Element systems.

The purpose is to allow SnapCenter / Data Fabric benefits for
critical host files locally stored on hosts. An example of such
files would be DB dump files. Also for files under a particular 
directory on hosts. Lastly, directories and files under path.

#################################################################################

Goal of this Sub-module is to
allow for local hosts to use ONTAP NFS/CIFS as NAS target to replicate their 
Direct Attached Storage (“DAS”) filesystems to. 


#################################################################################

There are known limitations. 


      * Please see limitations in the Readme_Before_Using.txt


#################################################################################

It is assumed you have already read the helpful information found
in the Readme_Before_Using.txt file.

#################################################################################

[ FYI ]
---------------------------------
  
  This document should be read entirely. At the end of this document are helpful
  suggestions for running this in your environment.

  The use of ln2on and ln2sf are synonymous.


[ TERMS ]
---------------------------------

	SnapCenter 4.x is also referred to as SCenter.

  DPG, DP Glue are the same.

  1MB is 1048576 bytes. This is related to user defined buffering.

	DUBR is the same as its ln2on sub-module in this document.

  DEST is same as DESTINATION or TARGET.

  SRC is same as SOURCE.

  Local storage is same as DAS.

#################################################################################




[ Conceptual Architecture ]
---------------------------------

> Use Case Example

* Let's say an IT group uses NetApp SnapCenter and NetApp ONTAP LUNs
* But there is a WIN or LIN server that has local storage only
* The host stores DB or application dumps / output directories and files 
  that need replicated / copied / protected on to a NetApp target
* SnapCenter does not offer agents for OS not using NetApp storage
* The cost cannot be justified to buy yet another backup solution for these few
* After all, the database has capabilities to backup itself
* So the DBA dumps data backups each night to a "dump file"
* SnapCenter Admin needs to protect that dump file
* What does one do?

> Inferior Approach

* The DB / App Admin could be given a "share"/"export" on NetApp ONTAP 
  or a LUN on NetApp SolidFire over iSCSI
* And that Admin could simply adjust the dumps / output to go there
* However it would not be managed centrally, would take longer to complete
  over the network and has no centralized scheduling/monitoring

> Better Approach

* SnapCenter 4x could use the DP GLUE, particulary the DUBR module
* The important replication and versioning of directories/files 
  to NetApp target can be centrally managed
* And once it lands on NetApp it can be protected with NetApp ONTAP snapshot 
* Success, failure and details are recorded

> How 

* Using SCenter 4x, one would deploy the DP Glue plugin-mode
* The WIN or LIN host that is part of SCenter would run DP Glue
* DP Glue would replicate the special dirs/files to NetApp (eg ONTAP) target
* DP Glue manages runlevel codes and interfaces that SCenter expects
* Once complete SCenter will record the logs and results
* SCenter ensures snapshot of the destination volume on NetApp Storage (eg ONTAP)



[ Using with SCenter as Custom Plugin]
---------------------------------

> Basic Steps

* Follow all directives found in DPGLUE\Readme_Before_Using.txt
* Ensure SCenter 4x is running in the environment
* Know that DP Glue is for 64bit OS
* And it is case sensitive
* Assume NetApp ONTAP SAN/NAS is the target (CVO / OTS / OnPrem)
* Deploy DP Glue properly in plugin-mode into SCenter 
      - This means the SC Admin will prepare the DP GLUE Plugin
        using the Readme_Before_Using.txt
      - The final zip file prepared using these Readme instructions
        will be called "SnapCenter Plug-in for DP Glue.zip"
      - The SC Admin will uploade this zip file to SnapCenter
        by selecting a desired host in the SnapCenter GUI, and
        performing a Modify the Add Plugin.
      - Such a host is one that does not use NetApp technology 
        for its storage, but rather DAS / local disk.
      - Ensure SnapCenter has had at least (1) ONTAP system
        added to its management.
      - Using SnapCenter, you will create a LUN or NAS Share
        (a Volume with protocol access of iSCSI, CIFS or NFS)
        on this ONTAP system that the desired host can access
        and write its backup replicas to.
      - often NAS Shares work best, especially since CIFS
        UNCs are support
      - You will then create a Resource of type DP Glue and
        with the property of DAS Host Filesystems
      - When you then click on this newly created Resource twice
        a Resource Group wizard will appear.
      - When you create the resource group job, the ONTAP Volume
        created above will be pre-requisite, and you will enter
        it in the wizard. For instance, if you are using H:\
        as a mountpoint to the ONTAP Volume over the CIFS protocol
        then you would enter H:\ in the dialog requiring such a
        filesystem area
      - You will not be able to filesystem quiesce the 
        source dirs/files on the desired host because it is not on NetApp
      - As you continue to use the Resource Group wizard, the
        custom Application key value pairs must
        be set using the keys DPG_ARG1_QUI, DPG_ARG2_QUI and DPG_ARG3_QUI
        and also using the keys DPG_ARG1_UNQ, DPG_ARG2_UNQ and DPG_ARG3_UNQ
      - It is wise to set the UNQ values to do nothing using the 
        underscore such as "d_f". SnapCenter will run an unquiesce, so
        you must set these UNQ values. But all the work was done during 
        quiesce.
      - Under this item in the wizard is another section that asks if you
        wish to make a filesystem consistent snapshot. If you are using a
        NetApp LUN as your ONTAP Volume target, then you can say Yes.
        Otherwise always say no. (It defaults to yes !)
      - Set up the desired schedules and other parameters to complete
        the SC workflow

> What SC does with the Resource Group JOB you set up for the Host?

      - When the Resource Group's backup is triggered
      - the first command sent to DP GLUE will be "-quiesce"
      - DP GLUE will follow the instructions given it
        by using the values provided by the custom application key value pairs,
        namely, DPG_ARG1_QUI, DPG_ARG2_QUI and DPG_ARG3_QUI.
      - These will replicate dirs/files from the desired host to
        the ONTAP Volume you created for it
      - SnapCenter will record whether DP Glue succeeds or not
      - Assuming success it will snapshot ONTAP Volume, protecting the 
        replica of the desired host's dirs/files
      - SC will then send the 2nd command to DP GLUE, namely "-unquiesce"
      - DP GLUE will follow the instructions given it
        by using the values provided by the custom key value pairs,
        namely, DPG_ARG1_UNQ, DPG_ARG2_UNQ and DPG_ARG3_UNQ.



> What SC commands to DP Glue are supportable?

  	  -describe	     supported, not used by SC

      	- or -
      
      -discover      not supported
      
        - or -
      
      -quiesce       supported, currently used by SC;
                     requires 3 Key/Value pairs with _QUI suffix.
      
        - or -
      
      -unquiesce     supported, currently used by SC;
                     requires 3 Key/Value pairs with _UNQ suffix.
      
        - or -
      
      -restore_pre   supported, not used by SC
      
        - or -
      
      -restore_pre   supported, not used by SC
      
        - or -
      
      -clone_pre	   supported, not used by SC
      
      	- or -
      
      -clone_post    supported, not used by SC
      
        - or -
      
      -scdump        supported, not used by SC
      
        - or -
      
      -backup        supported, not used by SC
      
        - or -
      
      -run           supported on command-line only for testing
                     requires the 3 Key/Value pairs with _RUN suffix
                     in the runtime environment.


> What are the specifics around the customized key value pairs?

    * Again, as part of the workflow for setting up a Resource
      Group Job, (6) key value pairs must be set up in the
      section of the SC wizard known as Customer Key Value Pairs
      when you setup the Resource Group Job
    * Again, they are: 

        - DPG_ARG1_QUI, DPG_ARG2_QUI and DPG_ARG3_QUI, which
          are used when SC sends DP GLUE the "-quiesce" command

          and

        - and DPG_ARG1_UNQ, DPG_ARG2_UNQ and DPG_ARG3_UNQ, which
          are used when SC sends DP GLUE the "-unquiesce" command

    * As mentioned above, the -quiesce and -unquiesce are the
      only commands SC will send DP GLUE presently. This is 
      why *_QUI and *_UNQ suffixes on the keys are relevant.

    * When setting the values for these 6 keys, following this standard:

        DPG_ARG1_<QUI|UNQ> set to a value known as a module, no quotes. More below.
         
         	- and -
         
         DPG_ARG2_<QUI|UNQ> set to a value known as a modifier, in double quotes. More below.
        
        	- and -
         
        DPG_ARG3_<QUI|UNQ> set to a value known as a dative, in double quotes. More below.

    * Whereby the "_<QUI|UNQ>" is replaced by one of these suffixes.

       Currently these suffixes are supported in plugin-mode:

       _QUI as the suffix for when the SC command is -quiesce
       _UNQ as the suffix for when the SC command is -unquiesce


* The value for the DPG_ARG1_<QUI|UNQ> key follows this guidance:

    - this is called the module key/value pair
    - sometimes called "DPG Arg 1"
    - set this always to "dubr" w/o any quotes at all
    - for instance DPG_SC_ARG1_MODULE_QUI=dubr

* The value for the DPG_SC_ARG2_MODIFIER_<QUI|UNQ> key follows this guidance:

    - this is called the modifier key/value pair
    - sometimes called "DPG Arg 2"
    - place the value inside double quotes
    - based on the wishes of the user here are the values

      > for individual file operations, the syntax is ...
     
         "-ln2on-f[_|t|v|b|B]f-1[--v]"
      
      > or for just the file(s) under a particular directory, the syntax is ...
          
         "-ln2on-s[_|t|v|b|B]f-1[--v]"

      > or for a directory path with is subdirectories and files, the syntax is ...
          
         "-ln2on-d[_|t|v|b|B]f-1[--v]"

    > for instance DPG_SC_ARG2_MODIFIER_QUI="-ln2on-f_f-1"

    > you may 0 instead of 1; 1 means the DP GLUE job aborts if a failure of even 1 element being 
      backed up occurs; 0 means such are ignored and you could get a successful result even if some
      elements do not get replicated -- so to truly know results the logs must be consulted

    > the meaning of the value(s) are explained later below

    > NOTE: "b" and "B" are 2 different behaving modes in -ln2on modifier. 
      "B" is a baseline and always overlays! See more below.


* The value for the DPG_SC_ARG3_DATIVE_<QUI|UNQ> key follows this guidance:

    - this is called the dative key/value pair
    - sometimes called "DPG Arg 3"
    - place the value inside double quotes
    - note the use of ~ ; however commas , can be used a delims too
    - based on the wishes of the user here are the values

      > for individual file operations, when "-ln2on-f etc." was used, the syntax is ...........
     
        - "<JobNameDescrWord>~<SOURCE_DIR>[\|/]~<FILENAME>~<DESTINATION_DIR>[\|/]~<FILENAME>~<[BuffSizeNum[1-8]]>~<IndexNumber>"
        - EXAMPLE:
             DPG_SC_ARG3_DATIVE_QUI="NiteDumpHRDB~C:\~hrdb.dmp~\\dumpfiler\hrdb_share\~nitedumpcpy.dmp~1~0"   
        - Note that the directories (aka "DIR") end with the slash (LIN) or backslash (WIN) 
        - the [BuffSizeNum[1-8]] needs to be 1 in most cases, unless you are an expert and know the risks of > 1
        - The DESTINATION DIR must already exist. As you know this is also called a TARGET.
 

      > or for file(s) under a particular directory, as in when "-ln2on-s etc" is used, the syntax is .........
      
        - "<JobNameDescrWord>~<SOURCE_PARENT_DIR>[\|/]~<.>~<DESTINATION_PARENT_DIR>[\|/]~.~<[BuffSizeNum[1-8]]>~<IndexNumber>|-unique"
        - EXAMPLE:
             DPG_SC_ARG3_DATIVE_QUI="NitelyHrDir~C:\TEMP\~.~D:\BACKUP\~.~1~0"   
        - The example will duplicate the files under C:\TEMP, but no subdirectories, to this path
              D:\BACKUP\dpglue\ln2on\NitelyHrDir\0\x_BUR_DIR_x\
            and it will do so in a manner that matches what the (2) letters after -ln2on-s_ _ tell it.
        - more later on this
        - The DESTINATION DIR must already exist. As you know this is also called a TARGET.
        - also information (to help you know successfulness, timeframes and restore ) can be found at
              D:\BACKUP\dpglue\ln2on\NitelyHrDir\0\x_META_DIR_x

                  Began_x_1543805290_8sSPy_x_fle.txt
                  Ended_x_1543805290_8sSPy_x_fle.txt
                  FinishedWith_x_1543805290_8sSPy_x_fle.log
                  Param_x_1543805290_8sSPy_x_fle.ini
                  WorkedOn_x_1543805290_8sSPy_x_fle.log
                  WorkList_x_1543805290_8sSPy_x_fle.txt
                  Xform_x_1543805290_8sSPy_x_fle.ini
                  RestoreInfo_x_1543805290_8sSPy_x_fle.ini

        - Note that the directories (aka "DIR") end with the slash (LIN) or backslash (WIN)   
        - Note also that the 3rd to last argument is just a "." ... which is required to show current directory
        - Note "patterns" like * for al files are not supported for <FILENAME>. You must use the "." to mean all files
        - the [BuffSizeNum[1-8]] needs to be 1 in most cases, unless you are an expert and know the risks of > 1
        - as you can see the "IndexNumber" is key ... as it factors into the directory structure for where backup goes
        - more later on

      > or for file(s) under a particular directory, as in when "-ln2on-d etc" is used, the syntax is .........

        - "<JobNameDescrWord>~<SOURCE_PARENT_DIR>[\|/]~<.>~<DESTINATION_PARENT_DIR>[\|/]~.~<[BuffSizeNum[1-8]]>~<IndexNumber>|-unique"
              - EXAMPLE:
             DPG_SC_ARG3_DATIVE_QUI="DailyHrDir~C:\TEMP\~.~D:\BACKUP\~.~1~5"   
        - The example will duplicate all dirs, subdirs and files under C:\TEMP to this path
              D:\BACKUP\dpglue\ln2on\DailyHrDir\5\x_BUR_DIR_x\
            and it will do so in a manner that matches what the (2) letters after -ln2on-d_ _ tell it.
        - more later on this
        - The DESTINATION DIR must already exist. As you know this is also called a TARGET.
        - also information (to help you know successfulness, timeframes and restore ) can be found at
              D:\BACKUP\dpglue\ln2on\DailyHrDir\5\x_META_DIR_x

                  Began_x_1543805290_8sSPy_x_fle.txt
                  Ended_x_1543805290_8sSPy_x_fle.txt
                  FinishedWith_x_1543805290_8sSPy_x_fle.log
                  Param_x_1543805290_8sSPy_x_fle.ini
                  WorkedOn_x_1543805290_8sSPy_x_fle.log
                  WorkList_x_1543805290_8sSPy_x_fle.txt
                  Xform_x_1543805290_8sSPy_x_fle.ini

        - Note that the directories (aka "DIR") end with the slash (LIN) or backslash (WIN)   
        - Note also that the 3rd to last argument is just a "." ... which is required to show current directory
        - Note "patterns" like * for al files are not supported for <FILENAME>. You must use the "." to mean all files
        - the [BuffSizeNum[1-8]] needs to be 1 in most cases, unless you are an expert and know the risks of > 1
        - as you can see the "IndexNumber" is key ... as it factors into the directory structure for where backup goes
        - more later on

      > the meaning of the value(s) are explained later below

* details for syntax are explained later

[ Using without SCenter as CLI tool ]
---------------------------------------------

* variables are still used in the environmental settings
* the Key Value pairs (variables) would be
  DPG_ARG1_RUN, DPG_ARG2_RUN, DPG_ARG3_RUN
* values like the module, modifier and dative are the same
  as what was explained above
* this would be run from command line, not SC
* this affords the chance to test
* the first command (argument on commandline) would be -run
* with the 3 key value pairs set, with _RUN as suffix, you would
  make sure DP GLUE is extracted out of the zip file
* execute like this example
  EXAMPLE:

  "C:\PROGRAM FILES\NETAPP\COMMUNITYTOOLS\SNAPCENTER_CLI_FOR_DP_GLUE\DPGLU.EXE -run"

[ Using without SCenter nor variables as CLI ]
-----------------------------------------------

* key value pair variables do not need to always be used from CLI
* assuming no key value pairs set, then the command line is different
* -run is not used
* execute like this example
  EXAMPLE:

  /opt/netapp/communitytools/SNAPCENTER_CLI_FOR_DP_GLUE/DPGLU.BIN {continue below}
    "-ln2on-s_f-1" "Job1forDB~/tmp/dump~.~/backup/~.~1~7"


[ OVERALL DETAILS ] 
----------------------------

* Quiesce, Unquiesce do not
    behave in any different way from one another. It is the arguments that the
    Admin provides to the key value pairs that define their behavior.

* This is because the DP Glue user can set the Key Value pairs to the behaviors they wish.

* SCenter treats each of the commands (like -quiesce and -unquiesce) differently itself. Thus,
    DP Glue should consult SCenter documentation accordingly.

* When using SCenter and DP Glue to backup files to an ONTAP Filer, it is best to have SCenter
    snapshot the target flexvol after successul transport.

[ The Three Types of Operations ] 
------------------------------------------

* the argument, which we have referred as the "MODIFIER",
  begins as "-ln2on-f", this is called a specific name.
  This name is the "Single-file Operation". This is
  because it "acts on" single files.

* when the "MODIFIER" begins as "-ln2on-s", this
  is called the "Sweep File(s) Operation".
  This is because it acts on the file or files
  under a specific directory only.

* when the "MODIFIER" begins as "-ln2on-d", this
  is called the "Directory Path Operation".
  This is because it acts on the dirs, 
  subdires, files etc under a directory path.
 
* these three (3) types of operations do something
  to what is given in the "DATIVE" argument
  based on the two (2) letters which follow
  after the "f" or "s" or "d" as in "-ln2on-s_ _"

* the (2) letters supported after "f" are not
  always the same as supported after the rest

* we will start with "f"  

[ Capabilities of Single-file Operations ] 
------------------------------------------

* this type of operation is when "-ln2on-f" is
    the beginning of the modifier argument

* No meta characters like '*' are supported to express things like all files in a path!!!!!
* always finish SOURCE DIR and DESTINATION DIR with the correct slash or backslash!
* "f_f" refers to file do_nothing to file.  This is merely to test DP Glue to SCenter is
    working. Index number is ignored.
* "ftf" refers to source file tested to destination file. The source file is replicated
    as a temporary named file on the destination.  Then the temporary named file on the
    destination is removed.  This is to TEST the operating to prove it would have worked.
    Index number is ignored.
* "fvf" refers to source files versioned on to the destination as a file with a version stamp.
    It is very similar to ftf. But, its name is governed by the destination file name given
    with a version stamp on it.  This way many versions can be kept on the destination.
    Index number is ignored.
* "fBf" backs up the source file to the destination directory on to the file name given. 
    If the user defined destination directory and the named 
    file exists, IT IS OVERLAYED. This is intentional. BE CAREFUL. NOT SHOWN ON COMMANDLINE
    HELP BECAUSE IT IS DESTRUCTIVE!
* "fbf" backs up the source file to the destination directory on to the file name given. 
    If the user defined destination directory and its named 
    file exists, IT IS NOT OVERLAYED. This is intentional as versioning in the name is used.
    The destination filename becomes "jobname_indexNumber_filename_StartingStampOs_fbf_EndingStampOStime"
* Since "buffer" could blow out memory, use 1 typically.
* If you have so little memory that 1 blows out memory, cease usage on this host.
* No easy restore modifier capability is used on purpose. Do so by hand and know what you are doing.
* Remember that all keys and value are case sensitive.
* Even "ln2on" is NOT the same as "LN2ON". The former works. The latter does not. 

[ Considerations of Single-file Operations ] 
--------------------------------------------

* DP Glue does NOT provide support for retention settings on the file replicas
* This is on purpose.
* The end user must explicitly state which "replica version" to delete using the "fDf".
* As mentioned above, "fOf", "fNf" and "fBf" also use caps because they are impactful.
* Impactful is a fancy word for BE CAREFUL BECAUSE A FILE WILL GET CHANGED IN SOME WAY!
* One probably asks what is the POINT of all the f -- f behaviors. 
    - well, "fNf" allows you to rename a file ... so you can LOCK a dumpfile with new name
      first before a backup; and then rename it back to original after a backup.
    - "f_f" let's you check "plumbing" before a backup runs
    - "ftf" let's you actually test the entire process without impacting the desired replica
    - "fBf" also overlays the destination replica file each time ... and if a snapshot is taken
      after each backup ... then you may find FabricPools beneficial *if* your NetApp/Partner SE
      helps you test several times ahead. TEST TEST.
* Also, DP Glue is meant to be run as the QUIESCE and UNQUIESCE operations for a regular SCenter job
* it is best to have sufficient storage on the source server to hold (3) copies of the "important file"
* it is assumed that the source server has at least 256MB of free memory for DP Glue to run to be safe.
* if the end-user asks for more memory as a "buffer" than the source server has, DP Glue simply complies
  with the end-user with assumption the end user knows what they are doing

[ GOOD PRACTICES of Single-file Ops. ] 
--------------------------------------

* The words "good practice" are used, not "best practice" because end users know the best practice for their
  IT business!
* The good practice for the "important file replication" method can be 
  considered this workflow:
    
    - use SnapCenter with DP Glue in plugin mode
    - use the DUBR module with the "ln2on" sub-module
    - let's say the important file you want backed up is "FOO.dmp"
    - let's say it is located on the "D:\Dump\ directory
    - and this directory is located on "AcmeWinSrv1"
    - for our requirements, we will assume AcmeWinSrv1 has 
        (1) enough storage to hold a few copies of the FOO.dmp file
        (2) enough free memory to hold a buffer factor of 8 MB
        (3) and the AcmeWinSrv1 has at least 256MB of free memory
    - create a flexvol on ONTAP 9x system
    - you can name that flexvol for instance "FV4DPG10_FOO_DUMP_DEST"
    - the "FV4DPG10" prefix means "flexvol for DP Glue 1.0" by the way
    - for brevity we call this the "FV-dest" here 
    - Because AcmeWinSrv1 uses "SMB 2.x", you will want to share the "FV-dest"
    - Share the "FV-dest" as a similar name like "SMB4DPG10_FOO_DUMP_DEST"
    - Manually create a subdirectory, thereby proving configuration with a name
      like "DIR4DPG10_FOO_DUMP_DEST".

    - Lock down WIN security on "FV-dest" such that on AcmeWinSrv1 & SCenter can use
    - Security should also be adjusted to match the Norms of your business / IT
    - using the DP Glue plugin mode in SnapCenter, you could set things 
      to test for the 1st run as so :

        DPG_SC_ARG1_MODULE_QUI=DUBR
        DPG_SC_ARG2_MODIFIER_QUI="-ln2on-f_f-1"
        DPG_SC_ARG3_DATIVE_QUI="WillItWork~D:\Dump\~FOO.dmp~\\AcmeWinSrv1\FV4DPG10_FOO_DUMP_DEST\~FOOcpy.dmp~1~0"

        and

        DPG_SC_ARG1_MODULE_UNQ=DUBR
        DPG_SC_ARG2_MODIFIER_UNQ="-ln2on-f_f-1"
        DPG_SC_ARG3_DATIVE_UNQ="WillItWork~D:\Dump\~FOO.dmp~\\AcmeWinSrv1\FV4DPG10_FOO_DUMP_DEST\~FOOcpy.dmp~1~0"

    - Make sure SCenter is told about the "FV-dest" with the right credentials to snapshot
      this destination flexvol
    - run the SCenter job
    - did quiesce and unquiesce succeed? did the snapcenter job succeed?
    - and you got a "0" success result for the job
    - and a snapshot of "FV-dest"
    - If yes to all then the "plumbing" worked 
    - And thus since the above worked, use SCenter to adjust only this key / value:

      DPG_SC_ARG2_MODIFIER_UNQ="-ln2on-ftf-1"

    - run the SCenter job again
    - be patient ... it is writing to a temporarily file on the destination
    - it is merely doing a plumbing test during the QUIESCE portion of JOB
    - it is doing writing as part of UNQUIESCE portion of the JOB
    - did quiesce and unquiesce succeed? did the snapcenter job succeed?
    - and you got a "0" success result for the job
    - and a snapshot of "FV-dest" occured
    - do not look for the test file, btw, it will not be there
    - this is because "ftf" writes a tempfile and then deletes it
    - If yes to all then testing worked 
    - at this point, there is some level of flexibility ... however, let's try these
      settings now.

        DPG_SC_ARG1_MODULE_QUI=DUBR
        DPG_SC_ARG2_MODIFIER_QUI="-ln2on-fBf-1"
        DPG_SC_ARG3_DATIVE_QUI="NiteDumpOfDb~D:\Dump\~FOO.dmp~D:\Dump\~FOOlck.dmp~1~0"

        and

        DPG_SC_ARG1_MODULE_UNQ=DUBR
        DPG_SC_ARG2_MODIFIER_UNQ="-ln2on-fBf-1"
        DPG_SC_ARG3_DATIVE_UNQ="NiteDumpOfDb~D:\Dump\~FOOlck.dmp~\\AcmeWinSrv1\FV4DPG10_FOO_DUMP_DEST\~FOOcpy.dmp~1~0"

    - run the SCenter job again
    - be patient ... it is writing on AcmeWinSrv1 (and overlaying if there) a FOO lock file copy LOCALLY
    - if this accomplishes OK, then a snapshot is taken of "FV-dest" the way it is before the backup REMOTELY
    - if this succeeds, then a copy of the lock file is made REMOTELY to \\AcmeWinSrv1\FV4DPG10_FOO_DUMP_DEST\ .
    - the destination file name on the "FV-dest" will conform to the DEST file name given
    - because capital B was used in either QUI or UNQUI "fBf" the the destination file 
      is overlayed each time! Ouch! So snapshots are import on "FV-dest". On AcmeWinSrv1 you have a local copy of
      the source file until the next run.
    - (Safety tip: 
      if you use the small b as in "fbf" versions of the destination file name given will be maintained!)
    - if the QUIesce works, you have a local copy of the dump file until the next run.
    - if it does not work, no UNQUIESCE runs.
    - if the SCenter snapshot of "FV-dest" works, you have a nice history of your backed up files in a 
      space savings manner. And retention is thus controlled centrally due to snapshot functionality of ONTAP!
    - and if UNQUIESCE succeeds, you have a copy of the source on "FV-dest". It will be the ACTIVE one, better
      referred to as the most recent. But, not until the next run is a snapshot taken of it.
    - if anything fails, you must do careful cleanup and copies by hand to have a good solid replica.

    - Be careful and smart.

[ Capabilities of the Sweep File(s) Operation  ] 
-------------------------------------------------

* this type of operation is when "-ln2on-s" is
    the beginning of the modifier argument

* below are the only additions to "-ln2on-s"
    which should ever be used

* The Source file and Destination file arguments must both be
          "." in WIN and "." in LIN to work

* The Source directory and Destination directory
         arguments must end with "\" for WIN or "/" for LIN 
         to work

* The Source directory and Destination directory
         arguments must begin with Drive Letter colon e.g. D:\
         or "\\" to work in WIN

* "s_f"  does roughly the same as "f_f" see above
     for when "f_f" was explained; except
     the target directory structure for backup
     and meta is made.

* "stf" does roughly the same as "ftf" see above
     for when "ftf" was explained; except
     the target directory structure for backup
     and meta is made.

* "svf" does roughly the same as "fvf" see above
     for when "fvf" was explained; except
     the target directory structure for backup
     and meta is made, the files from under
     the SOURCE directory are placed at
     target under "BUR_DIR" with numerical
     version stamps on them. The form is
     "thePrefixVersionNumber_filename"

* "sbf" does roughly the same as "fbf" see above
     for when "fbf" was explained; except
     the target directory structure for backup
     and meta is made, the files from under
     the SOURCE directory are placed at
     target under "BUR_DIR" with numerical
     version stamps and tmpname to be rather
     unique in form of 
     "XthePrefixVersionNumber_tmpname_filename"

* "sBf" does roughly the same as "fBf" see above
     for when "fBf" was explained; except
     the target directory structure for backup
     and meta is made, the files from under
     the SOURCE directory are placed at
     target under "BUR_DIR" in the same
     name as the SOURCE. If it sees the dir, file,
     etc already exists it will overwrite them!!!!

[ Capabilities of the Directory Path Operation  ] 
-------------------------------------------------

* this type of operation is when "-ln2on-d" is
    the beginning of the modifier argument

* below are the only additions to "-ln2on-d"
    which should ever be used

* The Source file and Destination file arguments must both be
          "." in WIN and "." in LIN to work

* The Source directory and Destination directory
         arguments must end with "\" for WIN or "/" for LIN 
         to work

* The Source directory and Destination directory
         arguments must begin with Drive Letter colon e.g. D:\
         or "\\" to work in WIN

* "d_f"  does roughly the same as "f_f" see above
     for when "f_f" was explained; except
     the target directory structure for backup
     and meta is made.


* "dtf" does roughly the same as "ftf" see above
     for when "ftf" was explained; except
     the target directory structure for backup
     and meta is made.

* "dvf" does roughly the same as "fvf" see above
     for when "fvf" was explained; except
     the target directory structure for backup
     and meta is made, the paths, dirs, files
     etc from under
     the SOURCE directory are placed at
     target under "BUR_DIR" with numerical
     version stamps on them. The form is
     "thePrefixVersionNumber_filename"

* "dbf" does roughly the same as "fbf" see above
     for when "fbf" was explained; except
     the target directory structure for backup
     and meta is made, the paths, dirs, files
     etc from under
     the SOURCE directory are placed at
     target under "BUR_DIR" with numerical
     version stamps and tmpname to be rather
     unique in form of 
     "XthePrefixVersionNumber_tmpname_filename"

* "dBf" does roughly the same as "fBf" see above
     for when "fBf" was explained; except
     the target directory structure for backup
     and meta is made, the paths, dirs, files
     etc from under
     the SOURCE directory are placed at
     target under "BUR_DIR" in the same
     name as the SOURCE. If it sees the dir, file,
     etc already exists it will overwrite them!!!!


[ SUGGESTIONS on USAGE]
---------------------------------

> Here are some suggestions

  * test with commandline using -run & its key/value pairs first
  * set the _QUI key value pairs when running in SC to actually replicate the dirs/files
  * in this way SC will snapshot the target
  * do not set unquiesce to run if quiesce fails
  * of course you must set the _UNQ key value pairs for unquiesce for when quiesce succeeds
  * but in the modifier (arg2) of unquiesce you can use the "_" so it does nothing
  * if the SC timesout your DP GLUE job, cancelling it before it finishes, break up the
    amount of dirs/files backed up into more jobs
  * make it conditional on the existence of the ONTAP volume you target
  * make sure the source host has UNC read/write access to the ONTAP volume target
  * have a directory like "backuptarget" pre-created on the ONTAP volume target share
  * here is example of what to use in your environment

    - use snapcenter latest 4x release
    - set the custom application key value pairs when you create the Resource Group Job
      based on this example:

      DPG_ARG1_QUI=dubr
      DPG_ARG2_QUI="-ln2on-dBf-1--v"
      DPG_ARG3_QUI="MyJobName~C:\WINDOWS\TEMP\SOMEDIR\~.~\\ONTAP_SYSTEM\TARGET_VOLUME_SHARE\backuptarget\~.~1~-unique"
      DPG_ARG1_UNQ=dubr
      DPG_ARG2_UNQ="-ln2on-f_f-1--v"
      DPG_ARG3_UNQ="MyJobName~C:\WINDOWS\TEMP\SOMEDIR\~SomeFileName~\\OOntapShare\backuptarget\~unqtestfile.txt~1~-unique"

    - You are simply running a new full to a unique backup target subdirectory each time you run
    - SC will then snapshot the vol
    - the name of a subdirectory under the backup target will be a form of a date/time stamp
    - because of this, you can delete the oldest such backup directories (manually)
    - and allow snapshots of old dirs delete via SC schedule
    - finally, because every B is a full baseline IF you do not use -unique is it possible to overwite a baseline that is already present
    - deduplication should be good (assuming you schedule old snapshots and old baselines to be deleted)

[ VERBOSITY ]
---------------------------------

* adding "--v" to the end of MODIFIER argument makes
  verbosity occur so you can trouble shoot
EXAMPLE:  "-ln2on-f_f-1--v"


[ CALLOUTS ]
---------------------------------

* There is no incremental or differential capability yet
* There is no promise that this document does not have mistakes
* There could be errors in this doc or in the software that could lose data
* TEST and use with care


#####################################CONCLUSION##################################

[ NOTE WELL ]
---------------------------------
SnapCreator, SnapCenter & SnapProtect are products from NetApp.
NetApp Data Fabric is from NetApp as well.
PostgreSQL is 3rd party example see www.postgres.org

#####################################END#########################################
This document was revised on 23-APR-2020. Content may be dated.
#################################################################################

