#!/bin/bash

myEXIT=99

## This batch file is a primitive interface that permits DPGLU.BIN to be executed as SC plugin
## It is based on an example provided to developers of plugins by SC product


case "$1" in

## The following allows for SNAPCENTER usage ONLY ..............................................
## arguments come to this execution by DP_SC_ARGN_<..>_RUN environment vars  in SnapCenter
## documentation is included in this product that explains those variables

    "-quiesce" | "-unquiesce") # SC supported
    myEXIT=0
    myASK=${1}
    cd plugins
    cd native
    echo "SC_MSG#INFO#xxxx#Starting to run DPGLUE $myASK"
    ./DPGLU.BIN ${myASK}
    myEXIT=$?
    echo "SC_MSG#INFO#xxx#Concluding the running of DPGLUE"
    cd ..
    cd ..
    exit $myEXIT
    ;; #done

    "-run" | "-scdump" | "-describe") # CLI supported
    myEXIT=0
    myASK=${1}
    echo "SC_MSG#INFO#xxxx#Starting DPGLUE as $myASK"
    ./DPGLU.BIN ${myASK}
    myEXIT=$?
    echo "SC_MSG#INFO#xxx#Concluding the running of DPGLUE"
    exit $myEXIT
    ;; #done

    "-h_dubr") # CLI supported
    myEXIT=0
    myASK=${1}
    ##echo "SC_MSG#INFO#xxxx#Starting DPGLUE as $myASK"
    ./DPGLU.BIN ${myASK}
    myEXIT=$?
    ##echo "SC_MSG#INFO#xxx#Concluding the running of DPGLUE"
    exit $myEXIT
    ;; #done

    *)  #usage
        echo "_____SC Plugin usage: `basename $0` { -describe | -quiesce | -unquiesce }"
        echo "_____nonPlugin usage: `basename $0` { -run  | -h_dubr }"
        myEXIT=99
        exit $myEXIT
    ;; #usage is done


esac

exit 99 #just in case
